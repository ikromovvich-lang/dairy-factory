import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { useAuthStore } from './store';
import Layout from './components/common/Layout';
import LoginPage from './components/auth/LoginPage';
import Dashboard from './components/dashboard/Dashboard';
import MilkPage from './components/milk/MilkPage';
import ProductionPage from './components/production/ProductionPage';
import InventoryPage from './components/inventory/InventoryPage';
import SalesPage from './components/sales/SalesPage';
import AnalyticsPage from './components/analytics/AnalyticsPage';
import FarmersPage from './components/milk/FarmersPage';
import CustomersPage from './components/sales/CustomersPage';
import AlertsPage from './components/notifications/AlertsPage';

const Protected = ({ children }) => {
  const { token } = useAuthStore();
  return token ? children : <Navigate to="/login" replace />;
};

export default function App() {
  return (
    <BrowserRouter>
      <Toaster position="top-right" toastOptions={{ style: { borderRadius: '12px', fontFamily: 'Inter' } }} />
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route path="/" element={<Protected><Layout /></Protected>}>
          <Route index element={<Dashboard />} />
          <Route path="milk" element={<MilkPage />} />
          <Route path="farmers" element={<FarmersPage />} />
          <Route path="production" element={<ProductionPage />} />
          <Route path="inventory" element={<InventoryPage />} />
          <Route path="sales" element={<SalesPage />} />
          <Route path="customers" element={<CustomersPage />} />
          <Route path="analytics" element={<AnalyticsPage />} />
          <Route path="alerts" element={<AlertsPage />} />
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
