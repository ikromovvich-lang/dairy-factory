import { useEffect, useRef } from 'react';
import { io } from 'socket.io-client';
import { useAuthStore, useAlertStore, useSocketStore } from '../store';
import toast from 'react-hot-toast';

const WS_URL = import.meta.env.VITE_WS_URL || '';

export function useSocket() {
  const socket = useRef(null);
  const { token } = useAuthStore();
  const { addAlert } = useAlertStore();
  const { setConnected, addEvent } = useSocketStore();

  useEffect(() => {
    if (!token) return;

    socket.current = io(WS_URL, { auth: { token }, transports: ['websocket', 'polling'] });

    socket.current.on('connect', () => { setConnected(true); });
    socket.current.on('disconnect', () => { setConnected(false); });

    socket.current.on('new_alert', (alert) => {
      addAlert(alert);
      addEvent(alert);
      const icon = alert.severity === 'critical' ? '🚨' : alert.severity === 'warning' ? '⚠️' : 'ℹ️';
      if (alert.severity === 'critical') {
        toast.error(`${icon} ${alert.title}: ${alert.message}`, { duration: 8000 });
      } else {
        toast(`${icon} ${alert.title}`, { duration: 5000 });
      }
    });

    socket.current.on('milk_collected', (data) => {
      addEvent({ type: 'milk_collected', ...data });
      toast.success(`🥛 Sut qabul qilindi: ${data.liters}L - ${data.farmer}`, { duration: 4000 });
    });

    socket.current.on('batch_completed', (data) => {
      addEvent({ type: 'batch_completed', ...data });
      toast.success(`✅ Partiya tayyor: ${data.product} - ${data.qty}kg`, { duration: 4000 });
    });

    socket.current.on('sale_created', (data) => {
      addEvent({ type: 'sale', ...data });
      toast.success(`💰 Sotuv: ${data.customer} - ${Number(data.total).toLocaleString()} so'm`, { duration: 4000 });
    });

    socket.current.on('low_stock_alert', (data) => {
      toast.error(`⚠️ Kam zaxira: ${data.product} - ${data.quantity} qoldi`, { duration: 6000 });
    });

    return () => socket.current?.disconnect();
  }, [token]);

  return socket.current;
}
