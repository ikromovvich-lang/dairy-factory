import { create } from 'zustand';

export const useAuthStore = create((set) => ({
  user: JSON.parse(localStorage.getItem('dairy_user') || 'null'),
  token: localStorage.getItem('dairy_token'),
  setAuth: (user, token) => {
    localStorage.setItem('dairy_user', JSON.stringify(user));
    localStorage.setItem('dairy_token', token);
    set({ user, token });
  },
  logout: () => {
    localStorage.removeItem('dairy_user');
    localStorage.removeItem('dairy_token');
    set({ user: null, token: null });
  }
}));

export const useAlertStore = create((set, get) => ({
  alerts: [],
  unreadCount: 0,
  addAlert: (alert) => set(s => ({ alerts: [alert, ...s.alerts], unreadCount: s.unreadCount + 1 })),
  setAlerts: (alerts) => set({ alerts, unreadCount: alerts.filter(a => !a.is_read).length }),
  markRead: (id) => set(s => ({
    alerts: s.alerts.map(a => a.id === id ? { ...a, is_read: true } : a),
    unreadCount: Math.max(0, s.unreadCount - 1)
  })),
  clearUnread: () => set(s => ({ alerts: s.alerts.map(a => ({ ...a, is_read: true })), unreadCount: 0 }))
}));

export const useSocketStore = create((set) => ({
  connected: false,
  setConnected: (v) => set({ connected: v }),
  events: [],
  addEvent: (e) => set(s => ({ events: [e, ...s.events.slice(0, 49)] }))
}));
