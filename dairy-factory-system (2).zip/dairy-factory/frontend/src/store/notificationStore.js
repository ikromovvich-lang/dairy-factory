import { create } from 'zustand';

const useNotificationStore = create((set, get) => ({
  alerts: [],
  unreadCount: 0,

  setAlerts: (alerts) => set({ alerts, unreadCount: alerts.filter(a => !a.is_read).length }),
  addAlert: (alert) => set((s) => ({ alerts: [alert, ...s.alerts], unreadCount: s.unreadCount + 1 })),
  markRead: (id) => set((s) => ({
    alerts: s.alerts.map(a => a.id === id ? { ...a, is_read: true } : a),
    unreadCount: Math.max(0, s.unreadCount - 1)
  })),
  markAllRead: () => set((s) => ({ alerts: s.alerts.map(a => ({ ...a, is_read: true })), unreadCount: 0 })),
}));

export default useNotificationStore;
