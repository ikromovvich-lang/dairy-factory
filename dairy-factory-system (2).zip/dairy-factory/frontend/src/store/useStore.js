import { create } from 'zustand';
const useStore = create((set) => ({
  user: JSON.parse(localStorage.getItem('dairy_user') || 'null'),
  token: localStorage.getItem('dairy_token') || null,
  alerts: [], alertCount: 0, socketConnected: false, sidebarOpen: true,
  setAuth: (user, token) => { localStorage.setItem('dairy_user', JSON.stringify(user)); localStorage.setItem('dairy_token', token); set({ user, token }); },
  logout: () => { localStorage.removeItem('dairy_user'); localStorage.removeItem('dairy_token'); set({ user: null, token: null }); },
  setAlerts: (alerts) => set({ alerts, alertCount: alerts.filter(a => !a.is_read).length }),
  addAlert: (alert) => set(s => ({ alerts: [alert, ...s.alerts], alertCount: s.alertCount + 1 })),
  setSocketConnected: (v) => set({ socketConnected: v }),
  toggleSidebar: () => set(s => ({ sidebarOpen: !s.sidebarOpen }))
}));
export default useStore;
