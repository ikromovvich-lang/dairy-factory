import React, { useState, useEffect } from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useAuthStore, useAlertStore, useSocketStore } from '../../store';
import { useSocket } from '../../hooks/useSocket';
import { alertAPI } from '../../services/api';
import {
  LayoutDashboard, Droplets, Factory, Package, ShoppingCart,
  BarChart3, Bell, Users, UserCheck, LogOut, Menu, X, Wifi, WifiOff
} from 'lucide-react';

const NAV = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/milk', label: "Sut Qabuli", icon: Droplets },
  { to: '/farmers', label: 'Fermerlar', icon: Users },
  { to: '/production', label: 'Ishlab Chiqarish', icon: Factory },
  { to: '/inventory', label: 'Ombor', icon: Package },
  { to: '/sales', label: 'Sotuv', icon: ShoppingCart },
  { to: '/customers', label: 'Mijozlar', icon: UserCheck },
  { to: '/analytics', label: 'AI Tahlil', icon: BarChart3 },
  { to: '/alerts', label: 'Ogohlantirishlar', icon: Bell },
];

export default function Layout() {
  const [open, setOpen] = useState(true);
  const { user, logout } = useAuthStore();
  const { unreadCount, setAlerts } = useAlertStore();
  const { connected } = useSocketStore();
  const navigate = useNavigate();
  useSocket();

  useEffect(() => {
    alertAPI.getAll({ unread: true, limit: 20 }).then(setAlerts).catch(() => {});
  }, []);

  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden">
      <aside style={{ width: open ? '256px' : '64px', transition: 'width 0.3s', flexShrink: 0 }}
        className="bg-white border-r border-gray-100 flex flex-col shadow-sm z-20">
        <div className="flex items-center gap-3 px-4 py-5 border-b border-gray-100">
          <div className="w-9 h-9 bg-blue-600 rounded-xl flex items-center justify-center text-white text-lg flex-shrink-0">🥛</div>
          {open && <div><div className="font-bold text-gray-900 text-sm">SutMahsulot</div><div className="text-xs text-gray-400">Zavod Boshqaruv</div></div>}
          <button onClick={() => setOpen(!open)} className="ml-auto text-gray-400 hover:text-gray-600 p-1">
            {open ? <X size={16}/> : <Menu size={16}/>}
          </button>
        </div>
        <nav className="flex-1 py-3 overflow-y-auto">
          {NAV.map(({ to, label, icon: Icon }) => (
            <NavLink key={to} to={to} end={to === '/'}
              className={({ isActive }) =>
                `flex items-center gap-3 px-4 py-2.5 mx-2 rounded-xl mb-0.5 transition-all text-sm font-medium
                ${isActive ? 'bg-blue-50 text-blue-700' : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'}`}>
              <div className="relative flex-shrink-0">
                <Icon size={18}/>
                {to === '/alerts' && unreadCount > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 w-4 h-4 bg-red-500 text-white text-xs rounded-full flex items-center justify-center font-bold">
                    {unreadCount > 9 ? '9+' : unreadCount}
                  </span>
                )}
              </div>
              {open && <span>{label}</span>}
            </NavLink>
          ))}
        </nav>
        <div className="border-t border-gray-100 p-4">
          {open ? (
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center text-blue-700 font-bold text-sm flex-shrink-0">
                {user?.name?.[0] || 'U'}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium text-gray-900 truncate">{user?.name}</div>
                <div className="text-xs text-gray-400 capitalize">{user?.role}</div>
              </div>
              <button onClick={() => { logout(); navigate('/login'); }} className="text-gray-400 hover:text-red-500">
                <LogOut size={16}/>
              </button>
            </div>
          ) : (
            <button onClick={() => { logout(); navigate('/login'); }} className="w-full flex justify-center text-gray-400 hover:text-red-500 py-1">
              <LogOut size={18}/>
            </button>
          )}
          {open && (
            <div className="flex items-center gap-1.5 mt-2">
              {connected ? <Wifi size={11} className="text-green-500"/> : <WifiOff size={11} className="text-gray-400"/>}
              <span className={`text-xs ${connected ? 'text-green-600' : 'text-gray-400'}`}>
                {connected ? 'Real-vaqt ulandi' : 'Uzilgan'}
              </span>
            </div>
          )}
        </div>
      </aside>
      <main className="flex-1 overflow-auto min-w-0">
        <div className="p-6 max-w-7xl mx-auto">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
