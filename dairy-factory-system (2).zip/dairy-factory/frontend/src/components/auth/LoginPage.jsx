import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { authAPI } from '../../services/api';
import { useAuthStore } from '../../store';
import toast from 'react-hot-toast';

export default function LoginPage() {
  const [form, setForm] = useState({ email: 'admin@dairy.uz', password: 'Admin@2024!' });
  const [loading, setLoading] = useState(false);
  const { setAuth } = useAuthStore();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault(); setLoading(true);
    try {
      const data = await authAPI.login(form);
      setAuth(data.user, data.token);
      toast.success(`Xush kelibsiz, ${data.user.name}!`);
      navigate('/');
    } catch (err) { toast.error(err?.error || 'Login xatosi'); }
    finally { setLoading(false); }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-cyan-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-10">
          <div className="w-20 h-20 bg-blue-600 rounded-3xl flex items-center justify-center text-4xl mx-auto mb-4 shadow-lg shadow-blue-200">🥛</div>
          <h1 className="text-3xl font-bold text-gray-900">SutMahsulot</h1>
          <p className="text-gray-500 mt-2">Zavod Boshqaruv Tizimi</p>
        </div>
        <div className="bg-white rounded-3xl shadow-xl border border-gray-100 p-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">Kirish</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="label">Email</label>
              <input type="email" className="input" value={form.email}
                onChange={e => setForm({ ...form, email: e.target.value })} required />
            </div>
            <div>
              <label className="label">Parol</label>
              <input type="password" className="input" value={form.password}
                onChange={e => setForm({ ...form, password: e.target.value })} required />
            </div>
            <button type="submit" disabled={loading}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 rounded-xl transition-all disabled:opacity-50">
              {loading ? 'Kirish...' : 'Kirish'}
            </button>
          </form>
          <div className="mt-4 p-3 bg-blue-50 rounded-xl text-xs text-blue-600">
            <strong>Demo:</strong> admin@dairy.uz / Admin@2024!
          </div>
        </div>
      </div>
    </div>
  );
}
