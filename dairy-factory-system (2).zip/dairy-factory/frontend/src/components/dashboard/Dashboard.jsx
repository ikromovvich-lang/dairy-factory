import React, { useState, useEffect } from 'react'
import { dashboardAPI, alertAPI } from '../../services/api'
import { AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts'
import { Droplets, Factory, Package, TrendingUp, AlertTriangle, Clock, DollarSign, Users, RefreshCw } from 'lucide-react'
import { format, parseISO } from 'date-fns'

const PRODUCT_COLORS = { milk: '#0ea5e9', yogurt: '#f59e0b', tvorog: '#10b981', smetana: '#8b5cf6' }
const PRODUCT_LABELS = { milk: 'Sut', yogurt: 'Yogurt', tvorog: 'Tvorog', smetana: 'Smetana' }

function KPICard({ title, value, subtitle, icon: Icon, color, trend }) {
  return (
    <div className="card p-5 animate-in">
      <div className="flex justify-between items-start mb-3">
        <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${color}`}>
          <Icon size={20} className="text-white" />
        </div>
        {trend !== undefined && (
          <span className={`text-xs font-semibold px-2 py-1 rounded-full ${parseFloat(trend) >= 0 ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'}`}>
            {parseFloat(trend) >= 0 ? '↑' : '↓'} {Math.abs(parseFloat(trend))}%
          </span>
        )}
      </div>
      <p className="text-2xl font-bold text-slate-800 font-display">{value}</p>
      <p className="text-sm font-medium text-slate-600 mt-0.5">{title}</p>
      {subtitle && <p className="text-xs text-slate-400 mt-1">{subtitle}</p>}
    </div>
  )
}

export default function Dashboard() {
  const [kpis, setKpis] = useState(null)
  const [trends, setTrends] = useState(null)
  const [loading, setLoading] = useState(true)
  const [lastUpdated, setLastUpdated] = useState(new Date())

  const load = async () => {
    setLoading(true)
    try {
      const [k, t] = await Promise.all([dashboardAPI.getKPIs(), dashboardAPI.getTrends()])
      setKpis(k); setTrends(t); setLastUpdated(new Date())
    } catch (err) { console.error(err) }
    finally { setLoading(false) }
  }

  useEffect(() => { load(); const int = setInterval(load, 60000); return () => clearInterval(int); }, [])

  const formatCurrency = (v) => `${(Number(v)/1000).toFixed(0)}K so'm`
  const formatNum = (v) => Number(v || 0).toLocaleString()

  if (loading && !kpis) return (
    <div className="flex items-center justify-center h-64">
      <div className="text-center"><div className="w-12 h-12 border-4 border-sky-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" /><p className="text-slate-500">Yuklanmoqda...</p></div>
    </div>
  )

  const inventoryData = kpis?.inventory_by_type?.map(i => ({ name: PRODUCT_LABELS[i.product_type] || i.product_type, value: parseFloat(i.total_qty), color: PRODUCT_COLORS[i.product_type] || '#94a3b8' })) || []
  const milkTrend = trends?.milk_trend?.map(d => ({ date: format(parseISO(d.collection_date), 'dd/MM'), liters: parseFloat(d.liters) })) || []
  const salesTrend = trends?.sales_trend?.map(d => ({ date: format(parseISO(d.order_date), 'dd/MM'), revenue: parseFloat(d.revenue) })) || []

  return (
    <div className="space-y-6 animate-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 font-display">Boshqaruv paneli</h1>
          <p className="text-slate-500 text-sm">{format(new Date(), 'dd MMMM yyyy')} · Oxirgi yangilanish: {format(lastUpdated, 'HH:mm')}</p>
        </div>
        <button onClick={load} className="btn-secondary text-sm"><RefreshCw size={16} />Yangilash</button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Bugungi sut" value={`${formatNum(kpis?.milk_today)}L`} subtitle={`Kecha: ${formatNum(kpis?.milk_yesterday)}L`} icon={Droplets} color="bg-sky-500" trend={kpis?.milk_change_pct} />
        <KPICard title="Bugungi daromad" value={formatCurrency(kpis?.revenue_today)} subtitle={`Oylik: ${formatCurrency(kpis?.revenue_month)}`} icon={DollarSign} color="bg-emerald-500" />
        <KPICard title="Faol partiyalar" value={kpis?.active_batches || 0} subtitle="Ishlab chiqarilmoqda" icon={Factory} color="bg-amber-500" />
        <KPICard title="Ombor qiymati" value={formatCurrency(kpis?.inventory_value)} subtitle={`${kpis?.low_stock_count || 0} mahsulot kam`} icon={Package} color="bg-violet-500" />
      </div>

      {/* Alerts */}
      {(kpis?.expiring_soon > 0 || kpis?.low_stock_count > 0) && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {kpis.low_stock_count > 0 && (
            <div className="card p-4 border-l-4 border-amber-400 bg-amber-50/50">
              <div className="flex items-center gap-2 mb-3">
                <AlertTriangle size={18} className="text-amber-500" />
                <span className="font-semibold text-amber-700">Kam zaxira ({kpis.low_stock_count})</span>
              </div>
              {kpis.low_stock_items?.map(item => (
                <div key={item.id} className="flex justify-between text-sm py-1.5 border-b border-amber-100 last:border-0">
                  <span className="text-slate-700">{item.product_name}</span>
                  <span className="font-mono text-amber-700 font-semibold">{parseFloat(item.quantity).toFixed(0)}{item.unit}</span>
                </div>
              ))}
            </div>
          )}
          {kpis.expiring_soon > 0 && (
            <div className="card p-4 border-l-4 border-red-400 bg-red-50/50">
              <div className="flex items-center gap-2 mb-3">
                <Clock size={18} className="text-red-500" />
                <span className="font-semibold text-red-700">Muddati tugaydi ({kpis.expiring_soon})</span>
              </div>
              {kpis.expiring_items?.map(item => (
                <div key={item.id} className="flex justify-between text-sm py-1.5 border-b border-red-100 last:border-0">
                  <span className="text-slate-700">{item.product_name}</span>
                  <span className="font-mono text-red-700 font-semibold">{item.expiration_date}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="card p-5 lg:col-span-2">
          <h3 className="section-title mb-4">Sut yig'imi trendi (14 kun)</h3>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={milkTrend}>
              <defs><linearGradient id="milkGrad" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#0ea5e9" stopOpacity={0.2}/><stop offset="95%" stopColor="#0ea5e9" stopOpacity={0}/></linearGradient></defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
              <Tooltip formatter={(v) => [`${v.toLocaleString()}L`, 'Sut']} contentStyle={{ borderRadius: 12, border: '1px solid #e2e8f0', boxShadow: '0 4px 20px rgba(0,0,0,0.08)' }} />
              <Area type="monotone" dataKey="liters" stroke="#0ea5e9" strokeWidth={2.5} fill="url(#milkGrad)" dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
        <div className="card p-5">
          <h3 className="section-title mb-4">Ombor holati</h3>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie data={inventoryData} cx="50%" cy="50%" innerRadius={55} outerRadius={85} paddingAngle={3} dataKey="value">
                {inventoryData.map((e, i) => <Cell key={i} fill={e.color} />)}
              </Pie>
              <Tooltip formatter={(v) => [`${v.toFixed(1)}kg`, '']} contentStyle={{ borderRadius: 12 }} />
              <Legend formatter={(v) => <span className="text-xs text-slate-600">{v}</span>} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="card p-5">
        <h3 className="section-title mb-4">Savdo daromadi (14 kun)</h3>
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={salesTrend}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
            <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} tickFormatter={v => `${(v/1000000).toFixed(1)}M`} />
            <Tooltip formatter={(v) => [`${Number(v).toLocaleString()} so'm`, 'Daromad']} contentStyle={{ borderRadius: 12, border: '1px solid #e2e8f0' }} />
            <Bar dataKey="revenue" fill="#10b981" radius={[6,6,0,0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}
