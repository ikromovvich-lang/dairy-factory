import React, { useState, useEffect } from 'react';
import { inventoryAPI } from '../../services/api';
import toast from 'react-hot-toast';
import { format } from 'date-fns';

const PRODUCT_ICONS = { milk: '🥛', yogurt: '🫙', tvorog: '🧀', smetana: '🍶' };
const PRODUCT_LABELS = { milk: 'Sut', yogurt: 'Yogurt', tvorog: 'Tvorog', smetana: 'Qatiq' };
const PRODUCT_COLORS = { milk: '#0ea5e9', yogurt: '#8b5cf6', tvorog: '#f59e0b', smetana: '#10b981' };

export default function InventoryPage() {
  const [items, setItems] = useState([]);
  const [summary, setSummary] = useState({ summary: [], expiring_soon: [], low_stock: [] });
  const [adjustModal, setAdjustModal] = useState(null);
  const [adjustQty, setAdjustQty] = useState('');
  const [loading, setLoading] = useState(false);
  const [filter, setFilter] = useState('all');

  useEffect(() => { fetchData(); }, []);

  const fetchData = async () => {
    try {
      const [inv, sum] = await Promise.all([inventoryAPI.getAll(), inventoryAPI.getSummary()]);
      setItems(inv.data);
      setSummary(sum.data);
    } catch {}
  };

  const handleAdjust = async () => {
    setLoading(true);
    try {
      await inventoryAPI.adjust(adjustModal.id, { quantity: adjustQty, reason: 'Manual adjustment' });
      toast.success('✅ Ombor yangilandi!');
      setAdjustModal(null);
      fetchData();
    } catch (err) { toast.error(err.response?.data?.error || 'Xatolik'); }
    finally { setLoading(false); }
  };

  const filteredItems = filter === 'low' ? items.filter(i => parseFloat(i.quantity) <= parseFloat(i.min_stock_alert))
    : filter === 'expiring' ? items.filter(i => {
        const d = new Date(i.expiration_date) - new Date();
        return d < 3 * 86400000;
      }) : items;

  const getDaysToExpiry = (date) => {
    if (!date) return null;
    return Math.floor((new Date(date) - new Date()) / 86400000);
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-800">📦 Ombor Boshqaruvi</h1>
        <p className="text-slate-500 text-sm mt-1">Real vaqt mahsulot zaxirasi va monitoring</p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {summary.summary?.map(s => (
          <div key={s.product_type} className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-2xl">{PRODUCT_ICONS[s.product_type]}</span>
              <span className="text-sm font-semibold text-slate-700">{PRODUCT_LABELS[s.product_type]}</span>
            </div>
            <p className="text-2xl font-bold" style={{color: PRODUCT_COLORS[s.product_type]}}>
              {Number(s.total_quantity).toFixed(0)} kg
            </p>
            <p className="text-xs text-slate-400 mt-1">{s.batch_count} partiya</p>
          </div>
        ))}
      </div>

      {/* Alerts */}
      {summary.expiring_soon?.length > 0 && (
        <div className="bg-red-50 border border-red-200 rounded-2xl p-4">
          <h4 className="font-bold text-red-700 mb-2">🚨 Muddati yaqin mahsulotlar:</h4>
          <div className="flex flex-wrap gap-2">
            {summary.expiring_soon.map(i => (
              <span key={i.id} className="bg-red-100 text-red-700 px-3 py-1 rounded-lg text-sm font-medium">
                {PRODUCT_ICONS[i.product_type]} {i.product_name} — {getDaysToExpiry(i.expiration_date)} kun
              </span>
            ))}
          </div>
        </div>
      )}
      {summary.low_stock?.length > 0 && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-2xl p-4">
          <h4 className="font-bold text-yellow-700 mb-2">⚠️ Kam zaxira:</h4>
          <div className="flex flex-wrap gap-2">
            {summary.low_stock.map(i => (
              <span key={i.id} className="bg-yellow-100 text-yellow-700 px-3 py-1 rounded-lg text-sm font-medium">
                {PRODUCT_ICONS[i.product_type]} {i.product_name}: {i.quantity}kg
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Filter */}
      <div className="flex gap-2">
        {[['all','Barchasi'],['low','Kam zaxira ⚠️'],['expiring','Muddati yaqin 🚨']].map(([v,l]) => (
          <button key={v} onClick={() => setFilter(v)}
            className={`px-4 py-2 rounded-xl text-sm font-medium transition ${filter === v ? 'bg-blue-600 text-white' : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200'}`}>
            {l}
          </button>
        ))}
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-50 text-slate-600 text-xs font-semibold uppercase tracking-wider">
                <th className="px-4 py-3 text-left">Mahsulot</th>
                <th className="px-4 py-3 text-right">Miqdor</th>
                <th className="px-4 py-3 text-right">Min. zaxira</th>
                <th className="px-4 py-3 text-center">Muddat</th>
                <th className="px-4 py-3 text-right">Narx</th>
                <th className="px-4 py-3 text-center">Holat</th>
                <th className="px-4 py-3 text-center">Amal</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filteredItems.map(item => {
                const daysLeft = getDaysToExpiry(item.expiration_date);
                const isLow = parseFloat(item.quantity) <= parseFloat(item.min_stock_alert);
                const isExpiring = daysLeft !== null && daysLeft <= 3;
                return (
                  <tr key={item.id} className={`hover:bg-slate-50 transition ${isLow || isExpiring ? 'bg-orange-50/30' : ''}`}>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <span className="text-lg">{PRODUCT_ICONS[item.product_type]}</span>
                        <div>
                          <div className="font-medium text-slate-800">{item.product_name}</div>
                          <div className="text-xs text-slate-400 font-mono">{item.ProductionBatch?.batch_id}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <span className={`font-bold ${isLow ? 'text-red-600' : 'text-slate-800'}`}>
                        {parseFloat(item.quantity).toFixed(1)} {item.unit}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right text-slate-500">{item.min_stock_alert} {item.unit}</td>
                    <td className="px-4 py-3 text-center">
                      {item.expiration_date ? (
                        <span className={`text-xs px-2 py-1 rounded-lg font-medium ${isExpiring ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'}`}>
                          {daysLeft !== null ? `${daysLeft} kun` : item.expiration_date}
                        </span>
                      ) : '—'}
                    </td>
                    <td className="px-4 py-3 text-right text-slate-600">
                      {item.price_per_unit ? `${Number(item.price_per_unit).toLocaleString()} so'm` : '—'}
                    </td>
                    <td className="px-4 py-3 text-center">
                      {isLow ? <span className="text-xs text-red-600 font-medium">⚠️ Kam</span>
                        : isExpiring ? <span className="text-xs text-orange-600 font-medium">⏰ Tez</span>
                        : <span className="text-xs text-green-600 font-medium">✅ Yaxshi</span>}
                    </td>
                    <td className="px-4 py-3 text-center">
                      <button onClick={() => { setAdjustModal(item); setAdjustQty(item.quantity); }}
                        className="text-xs px-3 py-1.5 rounded-lg bg-blue-50 text-blue-600 hover:bg-blue-100 font-medium transition">
                        Tahrirlash
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {filteredItems.length === 0 && (
            <div className="text-center py-12 text-slate-400">
              <div className="text-4xl mb-2">📦</div>
              <p>Ombor bo'sh</p>
            </div>
          )}
        </div>
      </div>

      {/* Adjust Modal */}
      {adjustModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-sm shadow-2xl">
            <h3 className="font-bold text-slate-800 mb-4">📝 Miqdorni Tahrirlash</h3>
            <p className="text-sm text-slate-500 mb-4">{adjustModal.product_name}</p>
            <div className="mb-4">
              <label className="block text-xs font-semibold text-slate-600 mb-1">Yangi miqdor ({adjustModal.unit})</label>
              <input type="number" value={adjustQty} onChange={e => setAdjustQty(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 outline-none focus:border-blue-400 text-sm"
                min="0" step="0.1" />
            </div>
            <div className="flex gap-3">
              <button onClick={handleAdjust} disabled={loading}
                className="flex-1 py-2.5 rounded-xl font-semibold text-white text-sm"
                style={{background: 'linear-gradient(135deg,#1e3a5f,#0ea5e9)'}}>
                {loading ? '⏳...' : '✅ Saqlash'}
              </button>
              <button onClick={() => setAdjustModal(null)}
                className="px-4 py-2.5 rounded-xl border border-slate-200 text-slate-600 text-sm hover:bg-slate-50">
                Bekor
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
