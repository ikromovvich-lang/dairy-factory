import React, { useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import useAuthStore from '../../store/authStore';
import useNotificationStore from '../../store/notificationStore';
import toast from 'react-hot-toast';

const NAV_ITEMS = [
  { path: '/', icon: '📊', label: 'Dashboard', exact: true },
  { path: '/milk', icon: '🥛', label: 'Sut qabul' },
  { path: '/production', icon: '🏭', label: 'Ishlab chiqarish' },
  { path: '/inventory', icon: '📦', label: 'Ombor' },
  { path: '/sales', icon: '💰', label: 'Sotish' },
  { path: '/analytics', icon: '🤖', label: 'AI Tahlil' },
  { path: '/farmers', icon: '👨‍🌾', label: 'Fermerlar' },
  { path: '/customers', icon: '🏪', label: 'Mijozlar' },
  { path: '/alerts', icon: '🔔', label: 'Ogohlantirishlar' },
];

export default function Layout({ children }) {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const { user, logout } = useAuthStore();
  const unreadCount = useNotificationStore(s => s.unreadCount);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    toast.success('Tizimdan chiqildi');
    navigate('/login');
  };

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden">
      {/* Sidebar */}
      <aside className={`${sidebarOpen ? 'w-64' : 'w-16'} transition-all duration-300 flex flex-col shadow-xl flex-shrink-0`}
        style={{background: 'linear-gradient(180deg, #1e3a5f 0%, #0f2840 100%)'}}>
        
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-white/10">
          {sidebarOpen && (
            <div className="flex items-center gap-3">
              <span className="text-2xl">🥛</span>
              <div>
                <div className="text-white font-bold text-sm">SutMahsulot</div>
                <div className="text-blue-300 text-xs">Zavod v1.0</div>
              </div>
            </div>
          )}
          <button onClick={() => setSidebarOpen(!sidebarOpen)}
            className="text-white/60 hover:text-white p-1 rounded-lg hover:bg-white/10 transition ml-auto">
            {sidebarOpen ? '←' : '→'}
          </button>
        </div>

        {/* Nav */}
        <nav className="flex-1 py-4 overflow-y-auto">
          {NAV_ITEMS.map(item => (
            <NavLink key={item.path} to={item.path} end={item.exact}
              className={({ isActive }) =>
                `flex items-center gap-3 px-4 py-3 mx-2 rounded-xl transition-all mb-1 ${
                  isActive ? 'bg-white/15 text-white' : 'text-white/60 hover:text-white hover:bg-white/10'
                }`}>
              <span className="text-xl w-6 flex-shrink-0 text-center">{item.icon}</span>
              {sidebarOpen && (
                <div className="flex items-center justify-between flex-1">
                  <span className="font-medium text-sm">{item.label}</span>
                  {item.path === '/alerts' && unreadCount > 0 && (
                    <span className="bg-red-500 text-white text-xs px-2 py-0.5 rounded-full font-bold">{unreadCount}</span>
                  )}
                </div>
              )}
            </NavLink>
          ))}
        </nav>

        {/* User */}
        <div className="p-4 border-t border-white/10">
          {sidebarOpen ? (
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-blue-500 flex items-center justify-center text-white font-bold text-sm flex-shrink-0">
                {user?.name?.charAt(0) || 'U'}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-white text-sm font-semibold truncate">{user?.name}</div>
                <div className="text-blue-300 text-xs capitalize">{user?.role}</div>
              </div>
              <button onClick={handleLogout} className="text-white/40 hover:text-red-400 transition text-sm" title="Chiqish">✕</button>
            </div>
          ) : (
            <button onClick={handleLogout} className="w-full flex justify-center text-white/40 hover:text-red-400 transition py-2 text-sm">✕</button>
          )}
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 overflow-y-auto min-w-0">
        {children}
      </main>
    </div>
  );
}
