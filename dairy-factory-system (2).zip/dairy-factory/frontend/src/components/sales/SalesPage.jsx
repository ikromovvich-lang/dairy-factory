import React, { useState, useEffect } from 'react'
import { salesAPI, customerAPI, inventoryAPI } from '../../services/api'
import { Plus, TrendingUp, ShoppingBag } from 'lucide-react'
import { format } from 'date-fns'
import toast from 'react-hot-toast'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts'

const STATUS = { pending:'Kutilmoqda', confirmed:'Tasdiqlandi', delivered:'Yetkazildi', cancelled:'Bekor' }
const STATUS_COLORS = { pending:'badge-yellow', confirmed:'badge-blue', delivered:'badge-green', cancelled:'badge-red' }

export default function SalesPage() {
  const [orders, setOrders] = useState([])
  const [customers, setCustomers] = useState([])
  const [inventory, setInventory] = useState([])
  const [summary, setSummary] = useState(null)
  const [revenue, setRevenue] = useState([])
  const [showCreate, setShowCreate] = useState(false)
  const [loading, setLoading] = useState(false)
  const [orderForm, setOrderForm] = useState({ customer_id:'', delivery_date:'', notes:'', items:[{ product_type:'milk', product_name:'', quantity:'', unit_price:'', discount_percentage:0 }] })

  const load = async () => {
    const [o, c, inv, s, r] = await Promise.all([salesAPI.getOrders({ limit:50 }), customerAPI.getAll(), inventoryAPI.getAll(), salesAPI.getSummary(), salesAPI.getRevenue({ days:14 })])
    setOrders(o.data||[]); setCustomers(c); setInventory(inv); setSummary(s); setRevenue(r)
  }
  useEffect(() => { load() }, [])

  const addItem = () => setOrderForm(f => ({ ...f, items: [...f.items, { product_type:'milk', product_name:'', quantity:'', unit_price:'', discount_percentage:0 }] }))
  const removeItem = (i) => setOrderForm(f => ({ ...f, items: f.items.filter((_,idx) => idx!==i) }))
  const updateItem = (i, field, val) => setOrderForm(f => ({ ...f, items: f.items.map((item,idx) => idx===i ? {...item,[field]:val} : item) }))

  const orderTotal = orderForm.items.reduce((s, it) => {
    const qty = parseFloat(it.quantity)||0, price = parseFloat(it.unit_price)||0, disc = parseFloat(it.discount_percentage)||0
    return s + qty * price * (1 - disc/100)
  }, 0)

  const createOrder = async (e) => {
    e.preventDefault(); setLoading(true)
    try {
      await salesAPI.createOrder(orderForm)
      toast.success('Buyurtma yaratildi!'); setShowCreate(false)
      setOrderForm({ customer_id:'', delivery_date:'', notes:'', items:[{ product_type:'milk', product_name:'', quantity:'', unit_price:'', discount_percentage:0 }] })
      load()
    } catch (err) { toast.error(err.error || 'Xatolik') }
    finally { setLoading(false) }
  }

  const updateStatus = async (id, status) => {
    await salesAPI.updateStatus(id, { status })
    toast.success('Holat yangilandi')
    load()
  }

  const revenueData = revenue.map(r => ({ date: r.order_date?.slice(5), revenue: parseFloat(r.revenue) }))

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div><h1 className="text-2xl font-bold text-slate-800 font-display">Savdo</h1><p className="text-slate-500 text-sm">Buyurtmalar va daromad</p></div>
        <button onClick={() => setShowCreate(true)} className="btn-primary text-sm"><Plus size={16}/>Buyurtma</button>
      </div>

      {/* KPIs */}
      {summary && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            {label:"Bugungi daromad", value:`${(parseFloat(summary.today)/1000000).toFixed(2)}M so'm`, icon:'💰'},
            {label:"Oylik daromad", value:`${(parseFloat(summary.month)/1000000).toFixed(2)}M so'm`, icon:'📈'},
            {label:"Jami buyurtmalar", value:summary.total_orders, icon:'📦'},
            {label:"Top mahsulot", value:summary.top_products?.[0]?.product_type||'—', icon:'⭐'}
          ].map((k,i)=>(
            <div key={i} className="card p-4"><div className="text-2xl mb-2">{k.icon}</div><p className="text-xl font-bold font-display text-slate-800">{k.value}</p><p className="text-sm text-slate-500 mt-0.5">{k.label}</p></div>
          ))}
        </div>
      )}

      {/* Revenue chart */}
      <div className="card p-5">
        <h3 className="section-title mb-4">14 kunlik daromad</h3>
        <ResponsiveContainer width="100%" height={180}>
          <BarChart data={revenueData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
            <XAxis dataKey="date" tick={{fontSize:11}} axisLine={false} tickLine={false} />
            <YAxis tick={{fontSize:11}} axisLine={false} tickLine={false} tickFormatter={v=>`${(v/1000000).toFixed(1)}M`} />
            <Tooltip formatter={v=>[`${Number(v).toLocaleString()} so'm`,'Daromad']} contentStyle={{borderRadius:12}} />
            <Bar dataKey="revenue" fill="#10b981" radius={[4,4,0,0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Orders table */}
      <div className="card overflow-hidden">
        <div className="p-4 border-b border-slate-100"><h3 className="section-title">So'nggi buyurtmalar</h3></div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wide">
              {['Raqam','Mijoz','Sana','Summa','To\'landi','Holat','Harakatlar'].map(h=><th key={h} className="text-left px-4 py-3 font-semibold">{h}</th>)}
            </tr></thead>
            <tbody>
              {orders.length === 0 && <tr><td colSpan={7} className="text-center py-12 text-slate-400">Buyurtmalar yo'q</td></tr>}
              {orders.map(o=>(
                <tr key={o.id} className="table-row">
                  <td className="px-4 py-3 font-mono font-semibold text-sky-600">{o.order_number}</td>
                  <td className="px-4 py-3"><p className="font-medium text-slate-800">{o.Customer?.name}</p><p className="text-xs text-slate-400">{o.Customer?.type}</p></td>
                  <td className="px-4 py-3 text-slate-500">{o.order_date}</td>
                  <td className="px-4 py-3 font-mono font-bold text-emerald-600">{(parseFloat(o.total_amount)/1000).toFixed(0)}K</td>
                  <td className="px-4 py-3 font-mono text-slate-600">{(parseFloat(o.paid_amount||0)/1000).toFixed(0)}K</td>
                  <td className="px-4 py-3"><span className={`badge ${STATUS_COLORS[o.status]}`}>{STATUS[o.status]}</span></td>
                  <td className="px-4 py-3">
                    {o.status === 'pending' && <button onClick={()=>updateStatus(o.id,'confirmed')} className="px-2 py-1 bg-sky-50 text-sky-600 rounded-lg text-xs hover:bg-sky-100">Tasdiqlash</button>}
                    {o.status === 'confirmed' && <button onClick={()=>updateStatus(o.id,'delivered')} className="px-2 py-1 bg-emerald-50 text-emerald-600 rounded-lg text-xs hover:bg-emerald-100">Yetkazildi</button>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create Order Modal */}
      {showCreate && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={()=>setShowCreate(false)}>
          <div className="card max-w-lg w-full p-6 animate-in max-h-[90vh] overflow-y-auto" onClick={e=>e.stopPropagation()}>
            <h3 className="section-title mb-4">🛒 Yangi buyurtma</h3>
            <form onSubmit={createOrder} className="space-y-4">
              <div><label className="label">Mijoz</label>
                <select value={orderForm.customer_id} onChange={e=>setOrderForm({...orderForm,customer_id:e.target.value})} className="input" required>
                  <option value="">Tanlang...</option>
                  {customers.map(c=><option key={c.id} value={c.id}>{c.name} ({c.type})</option>)}
                </select></div>
              <div><label className="label">Yetkazib berish sanasi</label><input type="date" value={orderForm.delivery_date} onChange={e=>setOrderForm({...orderForm,delivery_date:e.target.value})} className="input" /></div>
              
              <div>
                <div className="flex items-center justify-between mb-2"><label className="label mb-0">Mahsulotlar</label><button type="button" onClick={addItem} className="text-xs text-sky-600 hover:text-sky-700 font-medium">+ Qo'shish</button></div>
                {orderForm.items.map((item,i)=>(
                  <div key={i} className="bg-slate-50 p-3 rounded-xl mb-2 space-y-2">
                    <div className="grid grid-cols-2 gap-2">
                      <div><select value={item.product_type} onChange={e=>updateItem(i,'product_type',e.target.value)} className="input text-xs py-2">
                        {['milk','yogurt','tvorog','smetana'].map(t=><option key={t} value={t}>{t}</option>)}
                      </select></div>
                      <div><input value={item.product_name} onChange={e=>updateItem(i,'product_name',e.target.value)} placeholder="Mahsulot nomi" className="input text-xs py-2" /></div>
                    </div>
                    <div className="grid grid-cols-3 gap-2">
                      <div><input type="number" value={item.quantity} onChange={e=>updateItem(i,'quantity',e.target.value)} placeholder="Miqdor(kg)" className="input text-xs py-2" required /></div>
                      <div><input type="number" value={item.unit_price} onChange={e=>updateItem(i,'unit_price',e.target.value)} placeholder="Narx(so'm)" className="input text-xs py-2" required /></div>
                      <div className="flex gap-1"><input type="number" value={item.discount_percentage} onChange={e=>updateItem(i,'discount_percentage',e.target.value)} placeholder="Chegirma%" className="input text-xs py-2" />{i>0&&<button type="button" onClick={()=>removeItem(i)} className="px-2 bg-red-50 text-red-500 rounded-lg hover:bg-red-100">×</button>}</div>
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="bg-emerald-50 p-3 rounded-xl flex justify-between items-center">
                <span className="text-sm font-medium text-slate-600">Jami summa:</span>
                <span className="text-lg font-bold text-emerald-700">{orderTotal.toLocaleString()} so'm</span>
              </div>

              <div><label className="label">Izoh</label><textarea value={orderForm.notes} onChange={e=>setOrderForm({...orderForm,notes:e.target.value})} className="input resize-none" rows={2} /></div>
              <div className="flex gap-2"><button type="button" onClick={()=>setShowCreate(false)} className="btn-secondary flex-1 justify-center">Bekor</button><button type="submit" disabled={loading} className="btn-primary flex-1 justify-center">{loading?'...':'Buyurtma yaratish'}</button></div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
