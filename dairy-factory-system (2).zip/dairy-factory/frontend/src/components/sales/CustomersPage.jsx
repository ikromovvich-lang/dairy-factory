import React, { useState, useEffect } from 'react'
import { customerAPI } from '../../services/api'
import { Plus, Phone, MapPin, Building } from 'lucide-react'
import toast from 'react-hot-toast'

const TYPE_LABELS = { shop: 'Do\'kon', distributor: 'Distribyutor', restaurant: 'Restoran', individual: 'Jismoniy' }
const TYPE_COLORS = { shop: 'badge-blue', distributor: 'badge-green', restaurant: 'badge-yellow', individual: 'badge-gray' }

export default function CustomersPage() {
  const [customers, setCustomers] = useState([])
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState({ name:'',type:'shop',phone:'',email:'',address:'',tin_number:'',discount_percentage:0,credit_limit:0 })
  const [loading, setLoading] = useState(false)

  useEffect(() => { customerAPI.getAll().then(setCustomers).catch(()=>{}) }, [])

  const submit = async (e) => {
    e.preventDefault(); setLoading(true)
    try { await customerAPI.create(form); toast.success('Mijoz qo\'shildi!'); setShowForm(false); customerAPI.getAll().then(setCustomers) }
    catch (err) { toast.error(err.error || 'Xatolik') }
    finally { setLoading(false) }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div><h1 className="text-2xl font-bold text-slate-800 font-display">Mijozlar</h1><p className="text-slate-500 text-sm">{customers.length} ta mijoz</p></div>
        <button onClick={() => setShowForm(true)} className="btn-primary text-sm"><Plus size={16}/>Yangi mijoz</button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {customers.map(c => (
          <div key={c.id} className="card card-hover p-5">
            <div className="flex items-start justify-between mb-3">
              <div className="w-10 h-10 bg-emerald-100 rounded-xl flex items-center justify-center"><Building size={20} className="text-emerald-600" /></div>
              <span className={`${TYPE_COLORS[c.type] || 'badge-gray'} text-xs`}>{TYPE_LABELS[c.type]}</span>
            </div>
            <h3 className="font-bold text-slate-800">{c.name}</h3>
            <div className="mt-2 space-y-1.5 text-sm text-slate-500">
              {c.phone && <div className="flex items-center gap-2"><Phone size={13}/>{c.phone}</div>}
              {c.address && <div className="flex items-center gap-2"><MapPin size={13}/><span className="truncate">{c.address}</span></div>}
            </div>
            <div className="mt-3 pt-3 border-t border-slate-100 flex justify-between text-sm">
              <div><p className="text-xs text-slate-400">Chegirma</p><p className="font-bold text-amber-600">{c.discount_percentage}%</p></div>
              <div className="text-right"><p className="text-xs text-slate-400">Jami xaridlar</p><p className="font-bold text-slate-800">{(parseFloat(c.total_purchases||0)/1000000).toFixed(1)}M so'm</p></div>
            </div>
          </div>
        ))}
      </div>
      {showForm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={()=>setShowForm(false)}>
          <div className="card max-w-md w-full p-6 animate-in" onClick={e=>e.stopPropagation()}>
            <h3 className="section-title mb-4">Yangi mijoz</h3>
            <form onSubmit={submit} className="space-y-3">
              <div><label className="label">Nomi</label><input value={form.name} onChange={e=>setForm({...form,name:e.target.value})} className="input" required /></div>
              <div><label className="label">Turi</label><select value={form.type} onChange={e=>setForm({...form,type:e.target.value})} className="input">{Object.entries(TYPE_LABELS).map(([k,v])=><option key={k} value={k}>{v}</option>)}</select></div>
              <div className="grid grid-cols-2 gap-3">
                <div><label className="label">Telefon</label><input value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})} className="input" /></div>
                <div><label className="label">Chegirma %</label><input type="number" value={form.discount_percentage} onChange={e=>setForm({...form,discount_percentage:e.target.value})} className="input" /></div>
              </div>
              <div><label className="label">Manzil</label><input value={form.address} onChange={e=>setForm({...form,address:e.target.value})} className="input" /></div>
              <div><label className="label">STIR raqami</label><input value={form.tin_number} onChange={e=>setForm({...form,tin_number:e.target.value})} className="input" /></div>
              <div className="flex gap-2 pt-2">
                <button type="button" onClick={()=>setShowForm(false)} className="btn-secondary flex-1 justify-center">Bekor</button>
                <button type="submit" disabled={loading} className="btn-primary flex-1 justify-center">{loading?'...':'Saqlash'}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
