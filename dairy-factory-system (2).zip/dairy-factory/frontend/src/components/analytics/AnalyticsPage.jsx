import React, { useState, useEffect } from 'react'
import { analyticsAPI } from '../../services/api'
import { Brain, TrendingUp, TrendingDown, Minus, RefreshCw, Target, Zap } from 'lucide-react'
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, Radar, PolarGrid, PolarAngleAxis, Legend, AreaChart, Area } from 'recharts'
import toast from 'react-hot-toast'

const PRODUCT_COLORS = { milk:'#0ea5e9', yogurt:'#f59e0b', tvorog:'#10b981', smetana:'#8b5cf6' }
const PRODUCT_ICONS = { milk:'🥛', yogurt:'🫙', tvorog:'🧀', smetana:'🫶' }
const TREND_ICONS = { up: <TrendingUp size={14} className="text-emerald-500"/>, down: <TrendingDown size={14} className="text-red-500"/>, stable: <Minus size={14} className="text-slate-400"/> }

export default function AnalyticsPage() {
  const [forecast, setForecast] = useState(null)
  const [efficiency, setEfficiency] = useState([])
  const [milkData, setMilkData] = useState([])
  const [salesData, setSalesData] = useState([])
  const [loading, setLoading] = useState(false)
  const [activeTab, setActiveTab] = useState('forecast')

  const load = async () => {
    setLoading(true)
    try {
      const [f, e, m, s] = await Promise.all([
        analyticsAPI.getForecast(),
        analyticsAPI.getEfficiency({ days: 30 }),
        analyticsAPI.getMilkAnalytics({ days: 30 }),
        analyticsAPI.getSalesAnalytics({ days: 30 })
      ])
      setForecast(f); setEfficiency(e); setMilkData(m); setSalesData(s)
    } catch (err) { toast.error('Tahlil yuklanmadi') }
    finally { setLoading(false) }
  }

  useEffect(() => { load() }, [])

  const milkForecastData = forecast?.milk_forecast?.map(d => ({
    date: d.date?.slice(5), predicted: d.predicted_milk, confidence: d.confidence
  })) || []

  const efficiencyRadar = efficiency.map(e => ({
    product: (PRODUCT_ICONS[e.product_type]||'') + ' ' + (e.product_type||''),
    yield: parseFloat(e.avg_yield||0).toFixed(1),
    quality: parseFloat(e.avg_quality||0).toFixed(1),
    batches: parseInt(e.batches||0)
  }))

  const milkQualityData = (() => {
    const byDate = {}
    milkData.forEach(d => {
      if (!byDate[d.collection_date]) byDate[d.collection_date] = { date: d.collection_date?.slice(5) }
      byDate[d.collection_date][d.quality_grade] = parseFloat(d.liters||0)
    })
    return Object.values(byDate)
  })()

  const priorityColor = { high:'text-red-600 bg-red-50', medium:'text-amber-600 bg-amber-50', low:'text-slate-600 bg-slate-50' }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <div className="w-8 h-8 bg-violet-500 rounded-xl flex items-center justify-center"><Brain size={18} className="text-white"/></div>
            <h1 className="text-2xl font-bold text-slate-800 font-display">AI Tahlil</h1>
          </div>
          <p className="text-slate-500 text-sm">Sun'iy intellekt asosida prognoz va tavsiyalar</p>
        </div>
        <button onClick={load} disabled={loading} className="btn-secondary text-sm">
          <RefreshCw size={16} className={loading?'animate-spin':''}/>
          {loading ? 'Yangilanmoqda...' : 'Yangilash'}
        </button>
      </div>

      {loading && !forecast && (
        <div className="card p-12 text-center">
          <div className="w-12 h-12 border-4 border-violet-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"/>
          <p className="text-slate-500">AI modeli ishlamoqda...</p>
          <p className="text-xs text-slate-400 mt-1">Bu bir necha soniya olishi mumkin</p>
        </div>
      )}

      {forecast && (
        <>
          {/* AI Recommendations */}
          {forecast.recommendations?.length > 0 && (
            <div className="card p-5">
              <div className="flex items-center gap-2 mb-4">
                <Zap size={18} className="text-violet-500"/>
                <h3 className="section-title">AI Tavsiyalar</h3>
                <span className="badge-blue text-xs ml-auto">{forecast.model || 'AI v1.0'}</span>
              </div>
              <div className="space-y-3">
                {forecast.recommendations.map((rec, i) => (
                  <div key={i} className={`flex items-start gap-3 p-3 rounded-xl ${priorityColor[rec.priority]}`}>
                    <Target size={16} className="mt-0.5 flex-shrink-0"/>
                    <div>
                      <p className="text-sm font-medium">{rec.message}</p>
                      <span className="text-xs capitalize opacity-70">{rec.type} · {rec.priority} ustuvorlik</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Tabs */}
          <div className="flex gap-2 border-b border-slate-200">
            {[['forecast','📊 Prognoz'],['efficiency','⚙️ Samaradorlik'],['milk','🥛 Sut tahlili'],['sales','💰 Savdo tahlili']].map(([k,v])=>(
              <button key={k} onClick={()=>setActiveTab(k)} className={`px-4 py-2.5 text-sm font-medium border-b-2 transition-colors ${activeTab===k?'border-sky-500 text-sky-600':'border-transparent text-slate-500 hover:text-slate-700'}`}>{v}</button>
            ))}
          </div>

          {/* Forecast Tab */}
          {activeTab === 'forecast' && (
            <div className="space-y-6 animate-in">
              <div className="card p-5">
                <h3 className="section-title mb-1">7 kunlik sut prognozi</h3>
                <p className="text-xs text-slate-400 mb-4">Tarixiy ma'lumotlar asosida bashorat</p>
                <ResponsiveContainer width="100%" height={220}>
                  <AreaChart data={milkForecastData}>
                    <defs>
                      <linearGradient id="predGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.2}/>
                        <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9"/>
                    <XAxis dataKey="date" tick={{fontSize:11}} axisLine={false} tickLine={false}/>
                    <YAxis tick={{fontSize:11}} axisLine={false} tickLine={false}/>
                    <Tooltip formatter={(v,n) => [n==='predicted'?`${v.toLocaleString()}L`:`${v}%`, n==='predicted'?'Bashorat':'Ishonch']} contentStyle={{borderRadius:12}}/>
                    <Area type="monotone" dataKey="predicted" stroke="#8b5cf6" strokeWidth={2.5} fill="url(#predGrad)" dot={{r:4, fill:'#8b5cf6'}}/>
                    <Line type="monotone" dataKey="confidence" stroke="#f59e0b" strokeWidth={1.5} dot={false} strokeDasharray="4 2"/>
                  </AreaChart>
                </ResponsiveContainer>
              </div>

              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {forecast.sales_forecast?.map(sf => (
                  <div key={sf.product_type} className="card p-4">
                    <div className="text-2xl mb-2">{PRODUCT_ICONS[sf.product_type]}</div>
                    <p className="text-xl font-bold font-display text-slate-800">{parseFloat(sf.weekly_forecast).toFixed(0)}<span className="text-sm font-normal text-slate-400">kg</span></p>
                    <p className="text-sm text-slate-600 capitalize mt-0.5">{sf.product_type}</p>
                    <div className="flex items-center gap-1 mt-2">
                      {TREND_ICONS[sf.trend]}
                      <span className="text-xs text-slate-500 capitalize">{sf.trend === 'up' ? 'O\'smoqda' : sf.trend === 'down' ? 'Kamaymoqda' : 'Barqaror'}</span>
                    </div>
                    <div className="mt-2 bg-slate-100 rounded-full h-1.5">
                      <div className="h-1.5 rounded-full bg-violet-400" style={{width:`${sf.confidence}%`}}/>
                    </div>
                    <p className="text-xs text-slate-400 mt-1">{sf.confidence}% ishonch</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Efficiency Tab */}
          {activeTab === 'efficiency' && (
            <div className="space-y-6 animate-in">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="card p-5">
                  <h3 className="section-title mb-4">Ishlab chiqarish samaradorligi</h3>
                  <ResponsiveContainer width="100%" height={250}>
                    <RadarChart data={efficiencyRadar}>
                      <PolarGrid stroke="#e2e8f0"/>
                      <PolarAngleAxis dataKey="product" tick={{fontSize:11}}/>
                      <Radar name="Hosildorlik %" dataKey="yield" stroke="#0ea5e9" fill="#0ea5e9" fillOpacity={0.3}/>
                      <Radar name="Sifat balli" dataKey="quality" stroke="#10b981" fill="#10b981" fillOpacity={0.3}/>
                      <Legend/>
                      <Tooltip/>
                    </RadarChart>
                  </ResponsiveContainer>
                </div>
                <div className="card p-5">
                  <h3 className="section-title mb-4">Partiya statistikasi</h3>
                  <div className="space-y-3">
                    {efficiency.map(e => (
                      <div key={e.product_type} className="flex items-center gap-3">
                        <span className="text-xl w-8">{PRODUCT_ICONS[e.product_type]}</span>
                        <div className="flex-1">
                          <div className="flex justify-between text-sm mb-1">
                            <span className="font-medium capitalize">{e.product_type}</span>
                            <span className="font-mono text-slate-500">{parseFloat(e.avg_yield||0).toFixed(1)}% hosil</span>
                          </div>
                          <div className="h-2 bg-slate-100 rounded-full">
                            <div className="h-2 rounded-full bg-gradient-to-r from-sky-400 to-sky-600" style={{width:`${Math.min(parseFloat(e.avg_yield||0), 100)}%`}}/>
                          </div>
                          <div className="flex justify-between text-xs text-slate-400 mt-1">
                            <span>{e.batches} partiya</span>
                            <span>Sifat: {parseFloat(e.avg_quality||0).toFixed(0)}/100</span>
                          </div>
                        </div>
                      </div>
                    ))}
                    {efficiency.length === 0 && <p className="text-slate-400 text-center py-8">Ma'lumot yetarli emas</p>}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Milk Analytics Tab */}
          {activeTab === 'milk' && (
            <div className="animate-in">
              <div className="card p-5">
                <h3 className="section-title mb-4">Sifat darajasi bo'yicha sut (30 kun)</h3>
                <ResponsiveContainer width="100%" height={280}>
                  <BarChart data={milkQualityData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9"/>
                    <XAxis dataKey="date" tick={{fontSize:10}} axisLine={false} tickLine={false}/>
                    <YAxis tick={{fontSize:10}} axisLine={false} tickLine={false}/>
                    <Tooltip contentStyle={{borderRadius:12}}/>
                    <Legend/>
                    <Bar dataKey="premium" name="Premium" fill="#10b981" stackId="a" radius={[0,0,0,0]}/>
                    <Bar dataKey="first" name="1-sinf" fill="#0ea5e9" stackId="a"/>
                    <Bar dataKey="second" name="2-sinf" fill="#f59e0b" stackId="a"/>
                    <Bar dataKey="rejected" name="Rad" fill="#ef4444" stackId="a" radius={[4,4,0,0]}/>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {/* Sales Analytics Tab */}
          {activeTab === 'sales' && (
            <div className="animate-in">
              <div className="card p-5">
                <h3 className="section-title mb-4">Mahsulot bo'yicha savdo</h3>
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                  {salesData.map(s => (
                    <div key={s.product_type} className="bg-slate-50 rounded-xl p-4">
                      <div className="text-xl mb-2">{PRODUCT_ICONS[s.product_type]}</div>
                      <p className="text-lg font-bold font-display text-slate-800 capitalize">{s.product_type}</p>
                      <p className="text-sm text-emerald-600 font-medium">{(parseFloat(s.revenue||0)/1000000).toFixed(2)}M so'm</p>
                      <p className="text-xs text-slate-400 mt-1">{parseFloat(s.total_qty||0).toFixed(0)}kg sotildi</p>
                    </div>
                  ))}
                  {salesData.length === 0 && <p className="col-span-4 text-slate-400 text-center py-8">Ma'lumot yo'q</p>}
                </div>
                <ResponsiveContainer width="100%" height={200}>
                  <BarChart data={salesData.map(s=>({name:s.product_type, revenue:parseFloat(s.revenue||0), qty:parseFloat(s.total_qty||0)}))}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9"/>
                    <XAxis dataKey="name" tick={{fontSize:11}} axisLine={false} tickLine={false}/>
                    <YAxis tick={{fontSize:11}} axisLine={false} tickLine={false} tickFormatter={v=>`${(v/1000000).toFixed(1)}M`}/>
                    <Tooltip formatter={v=>[`${Number(v).toLocaleString()} so'm`,'Daromad']} contentStyle={{borderRadius:12}}/>
                    <Bar dataKey="revenue" radius={[6,6,0,0]}>
                      {salesData.map((s,i)=><rect key={i} fill={PRODUCT_COLORS[s.product_type]||'#94a3b8'}/>)}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  )
}
