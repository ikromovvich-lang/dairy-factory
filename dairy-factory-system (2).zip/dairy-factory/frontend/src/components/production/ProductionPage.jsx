import React, { useState, useEffect } from 'react';
import { productionAPI } from '../../services/api';
import toast from 'react-hot-toast';
import { format, addDays } from 'date-fns';

const STATUS_CONFIG = {
  planned: { label: 'Rejalashtirilgan', color: 'bg-slate-100 text-slate-600' },
  in_progress: { label: '⏳ Jarayonda', color: 'bg-blue-100 text-blue-700' },
  completed: { label: '✅ Tugallangan', color: 'bg-green-100 text-green-700' },
  failed: { label: '❌ Muvaffaqiyatsiz', color: 'bg-red-100 text-red-600' },
  recalled: { label: '🔄 Qaytarildi', color: 'bg-orange-100 text-orange-600' }
};

const PRODUCT_COLORS = { milk: '#0ea5e9', yogurt: '#8b5cf6', tvorog: '#f59e0b', smetana: '#10b981' };

export default function ProductionPage() {
  const [batches, setBatches] = useState([]);
  const [recipes, setRecipes] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [completeModal, setCompleteModal] = useState(null);
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({ recipe_id: '', milk_used_liters: '', quantity_planned: '', fat_percentage: '3.2', quality_score: '85', notes: '' });
  const [completeForm, setCompleteForm] = useState({ quantity_produced: '', quality_score: '88', notes: '' });
  const [filter, setFilter] = useState('all');

  useEffect(() => { fetchData(); }, []);

  const fetchData = async () => {
    try {
      const [b, r] = await Promise.all([productionAPI.getBatches({ limit: 50 }), productionAPI.getRecipes()]);
      setBatches(b.data.data);
      setRecipes(r.data);
    } catch {}
  };

  const handleCreate = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await productionAPI.createBatch(form);
      toast.success('🏭 Yangi partiya boshlandi!');
      setShowForm(false);
      setForm({ recipe_id: '', milk_used_liters: '', quantity_planned: '', fat_percentage: '3.2', quality_score: '85', notes: '' });
      fetchData();
    } catch (err) { toast.error(err.response?.data?.error || 'Xatolik'); }
    finally { setLoading(false); }
  };

  const handleComplete = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await productionAPI.completeBatch(completeModal.id, completeForm);
      toast.success('✅ Partiya muvaffaqiyatli tugallandi!');
      setCompleteModal(null);
      fetchData();
    } catch (err) { toast.error(err.response?.data?.error || 'Xatolik'); }
    finally { setLoading(false); }
  };

  const selectedRecipe = recipes.find(r => r.id === form.recipe_id);
  const filteredBatches = filter === 'all' ? batches : batches.filter(b => b.status === filter);

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">🏭 Ishlab Chiqarish</h1>
          <p className="text-slate-500 text-sm mt-1">Partiyalar va mahsulot ishlab chiqarish</p>
        </div>
        <button onClick={() => setShowForm(!showForm)}
          className="px-5 py-2.5 rounded-xl font-semibold text-white text-sm"
          style={{background: 'linear-gradient(135deg,#1e3a5f,#0ea5e9)'}}>
          + Yangi Partiya
        </button>
      </div>

      {/* Create Form */}
      {showForm && (
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-blue-100">
          <h3 className="font-bold text-slate-800 mb-4">🏭 Yangi Partiya Yaratish</h3>
          <form onSubmit={handleCreate} className="grid grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="lg:col-span-2">
              <label className="block text-xs font-semibold text-slate-600 mb-1">Mahsulot Retsepti *</label>
              <select value={form.recipe_id} onChange={e => setForm({...form, recipe_id: e.target.value})}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 outline-none focus:border-blue-400 text-sm" required>
                <option value="">-- Retsept tanlang --</option>
                {recipes.map(r => (
                  <option key={r.id} value={r.id}>{r.product_name} ({r.product_type}) — {r.price_per_unit?.toLocaleString()} so'm/kg</option>
                ))}
              </select>
              {selectedRecipe && (
                <p className="text-xs text-blue-600 mt-1">
                  ℹ️ 1 kg uchun {selectedRecipe.milk_per_unit}L sut | Yaroqlilik: {selectedRecipe.shelf_life_days} kun | Samaradorlik: {selectedRecipe.yield_percentage}%
                </p>
              )}
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">Ishlatilgan sut (L) *</label>
              <input type="number" value={form.milk_used_liters} onChange={e => setForm({...form, milk_used_liters: e.target.value})}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 outline-none focus:border-blue-400 text-sm"
                placeholder="1000" min="1" required />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">Rejalashtirilgan miqdor (kg) *</label>
              <input type="number" value={form.quantity_planned} onChange={e => setForm({...form, quantity_planned: e.target.value})}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 outline-none focus:border-blue-400 text-sm"
                placeholder="850" min="1" required />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">Yog'lik %</label>
              <input type="number" value={form.fat_percentage} onChange={e => setForm({...form, fat_percentage: e.target.value})}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 outline-none focus:border-blue-400 text-sm"
                placeholder="3.2" step="0.1" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">Sifat balli (1-100)</label>
              <input type="number" value={form.quality_score} onChange={e => setForm({...form, quality_score: e.target.value})}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 outline-none focus:border-blue-400 text-sm"
                placeholder="85" min="1" max="100" />
            </div>
            <div className="lg:col-span-2">
              <label className="block text-xs font-semibold text-slate-600 mb-1">Izoh</label>
              <input type="text" value={form.notes} onChange={e => setForm({...form, notes: e.target.value})}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 outline-none focus:border-blue-400 text-sm"
                placeholder="Qo'shimcha ma'lumot..." />
            </div>
            <div className="flex gap-3 items-end">
              <button type="submit" disabled={loading}
                className="flex-1 py-2.5 rounded-xl font-semibold text-white text-sm"
                style={{background: 'linear-gradient(135deg,#1e3a5f,#0ea5e9)'}}>
                {loading ? '⏳...' : '🚀 Boshlash'}
              </button>
              <button type="button" onClick={() => setShowForm(false)}
                className="px-4 py-2.5 rounded-xl border border-slate-200 text-slate-600 text-sm hover:bg-slate-50">
                Bekor
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Filter */}
      <div className="flex gap-2">
        {['all', 'in_progress', 'completed', 'planned'].map(f => (
          <button key={f} onClick={() => setFilter(f)}
            className={`px-4 py-2 rounded-xl text-sm font-medium transition ${filter === f ? 'bg-blue-600 text-white' : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200'}`}>
            {f === 'all' ? 'Barchasi' : STATUS_CONFIG[f]?.label || f}
          </button>
        ))}
      </div>

      {/* Batches Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
        {filteredBatches.map(batch => {
          const status = STATUS_CONFIG[batch.status] || STATUS_CONFIG.planned;
          const color = PRODUCT_COLORS[batch.product_type] || '#64748b';
          return (
            <div key={batch.id} className="bg-white rounded-2xl p-5 shadow-sm border border-slate-100 hover:shadow-md transition">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <div className="font-bold text-slate-800 text-sm">{batch.product_name}</div>
                  <div className="text-xs text-slate-400 font-mono mt-0.5">{batch.batch_id}</div>
                </div>
                <span className={`text-xs px-2 py-1 rounded-lg font-medium ${status.color}`}>{status.label}</span>
              </div>

              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-slate-500">Sut ishlatildi:</span>
                  <span className="font-semibold">{batch.milk_used_liters}L</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Rejalashtirilgan:</span>
                  <span className="font-semibold">{batch.quantity_planned}kg</span>
                </div>
                {batch.quantity_produced && (
                  <div className="flex justify-between">
                    <span className="text-slate-500">Ishlab chiqarildi:</span>
                    <span className="font-semibold text-green-600">{batch.quantity_produced}kg</span>
                  </div>
                )}
                {batch.yield_actual && (
                  <div className="flex justify-between">
                    <span className="text-slate-500">Samaradorlik:</span>
                    <span className={`font-semibold ${parseFloat(batch.yield_actual) >= 85 ? 'text-green-600' : 'text-orange-500'}`}>{parseFloat(batch.yield_actual).toFixed(1)}%</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-slate-500">Muddat:</span>
                  <span className="font-semibold text-sm">{batch.expiration_date}</span>
                </div>
              </div>

              <div className="flex gap-2 mt-4">
                {batch.status === 'in_progress' && (
                  <button onClick={() => { setCompleteModal(batch); setCompleteForm({ quantity_produced: batch.quantity_planned, quality_score: '88', notes: '' }); }}
                    className="flex-1 py-2 rounded-xl font-semibold text-white text-xs"
                    style={{background: 'linear-gradient(135deg,#10b981,#059669)'}}>
                    ✅ Tugallash
                  </button>
                )}
                {batch.qr_code_data && (
                  <a href={productionAPI.getQR(batch.batch_id)} target="_blank" rel="noreferrer"
                    className="px-3 py-2 rounded-xl border border-slate-200 text-slate-600 text-xs hover:bg-slate-50 font-medium">
                    QR 📷
                  </a>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {filteredBatches.length === 0 && (
        <div className="text-center py-16 text-slate-400">
          <div className="text-5xl mb-3">🏭</div>
          <p>Hali partiya yo'q</p>
        </div>
      )}

      {/* Complete Modal */}
      {completeModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md shadow-2xl">
            <h3 className="font-bold text-slate-800 mb-1">✅ Partiyani Tugallash</h3>
            <p className="text-slate-500 text-sm mb-4">{completeModal.product_name} — {completeModal.batch_id}</p>
            <form onSubmit={handleComplete} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">Ishlab chiqarilgan miqdor (kg) *</label>
                <input type="number" value={completeForm.quantity_produced} onChange={e => setCompleteForm({...completeForm, quantity_produced: e.target.value})}
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-200 outline-none focus:border-green-400 text-sm" required />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">Sifat balli (1-100)</label>
                <input type="number" value={completeForm.quality_score} onChange={e => setCompleteForm({...completeForm, quality_score: e.target.value})}
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-200 outline-none focus:border-green-400 text-sm" min="1" max="100" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">Izoh</label>
                <input type="text" value={completeForm.notes} onChange={e => setCompleteForm({...completeForm, notes: e.target.value})}
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-200 outline-none focus:border-green-400 text-sm" placeholder="..." />
              </div>
              <div className="flex gap-3">
                <button type="submit" disabled={loading}
                  className="flex-1 py-2.5 rounded-xl font-semibold text-white text-sm"
                  style={{background: 'linear-gradient(135deg,#10b981,#059669)'}}>
                  {loading ? '⏳...' : '✅ Tasdiqlash'}
                </button>
                <button type="button" onClick={() => setCompleteModal(null)}
                  className="px-4 py-2.5 rounded-xl border border-slate-200 text-slate-600 text-sm hover:bg-slate-50">
                  Bekor
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
