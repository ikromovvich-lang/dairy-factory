import React, { useEffect } from 'react'
import { Outlet, NavLink, useNavigate } from 'react-router-dom'
import { LayoutDashboard, Droplets, Factory, Package, ShoppingCart, BarChart3, Users, Truck, LogOut, Bell, Menu, Wifi, WifiOff } from 'lucide-react'
import useStore from '../../store/useStore'
import { alertAPI } from '../../services/api'

const navItems = [
  { to: '/', icon: LayoutDashboard, label: 'Boshqaruv' },
  { to: '/milk', icon: Droplets, label: 'Sut qabul' },
  { to: '/farmers', icon: Truck, label: 'Fermerlar' },
  { to: '/production', icon: Factory, label: 'Ishlab chiqarish' },
  { to: '/inventory', icon: Package, label: 'Omborxona' },
  { to: '/sales', icon: ShoppingCart, label: 'Savdo' },
  { to: '/customers', icon: Users, label: 'Mijozlar' },
  { to: '/analytics', icon: BarChart3, label: 'AI Tahlil' }
]

export default function Layout() {
  const { user, logout, alertCount, setAlerts, socketConnected, sidebarOpen, toggleSidebar } = useStore()
  const navigate = useNavigate()

  useEffect(() => {
    alertAPI.getAll().then(setAlerts).catch(() => {})
  }, [])

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden">
      {/* Sidebar */}
      <aside className={`${sidebarOpen ? 'w-60' : 'w-16'} flex-shrink-0 bg-slate-900 flex flex-col transition-all duration-300 z-30`}>
        <div className="p-4 flex items-center gap-3 border-b border-slate-800">
          <div className="w-9 h-9 bg-sky-500 rounded-xl flex items-center justify-center flex-shrink-0">
            <span className="text-lg">🥛</span>
          </div>
          {sidebarOpen && <div><p className="font-bold text-white text-sm font-display">SutMahsulot</p><p className="text-slate-400 text-xs">Factory ERP</p></div>}
        </div>
        <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
          {navItems.map(({ to, icon: Icon, label }) => (
            <NavLink key={to} to={to} end={to==='/'} className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${isActive ? 'bg-sky-500 text-white shadow-md shadow-sky-900/40' : 'text-slate-400 hover:text-white hover:bg-slate-800'}`
            }>
              <Icon size={18} className="flex-shrink-0" />
              {sidebarOpen && <span>{label}</span>}
            </NavLink>
          ))}
        </nav>
        <div className="p-3 border-t border-slate-800">
          {sidebarOpen && <div className="px-3 py-2 mb-2">
            <p className="text-white text-sm font-medium truncate">{user?.name}</p>
            <p className="text-slate-400 text-xs capitalize">{user?.role}</p>
          </div>}
          <button onClick={() => { logout(); navigate('/login'); }}
            className="flex items-center gap-3 w-full px-3 py-2.5 rounded-xl text-slate-400 hover:text-red-400 hover:bg-red-900/20 transition-colors text-sm">
            <LogOut size={18} />{sidebarOpen && 'Chiqish'}
          </button>
        </div>
      </aside>
      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="bg-white border-b border-slate-100 px-4 py-3 flex items-center justify-between flex-shrink-0">
          <button onClick={toggleSidebar} className="p-2 rounded-xl hover:bg-slate-100 text-slate-500 transition-colors">
            <Menu size={20} />
          </button>
          <div className="flex items-center gap-3">
            <div className={`flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-full ${socketConnected ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-100 text-slate-500'}`}>
              {socketConnected ? <Wifi size={12} /> : <WifiOff size={12} />}
              {socketConnected ? 'Jonli' : 'Offline'}
            </div>
            <button className="relative p-2 rounded-xl hover:bg-slate-100 text-slate-500 transition-colors">
              <Bell size={20} />
              {alertCount > 0 && <span className="absolute top-1 right-1 w-4 h-4 bg-red-500 text-white text-xs rounded-full flex items-center justify-center font-bold leading-none">{alertCount > 9 ? '9+' : alertCount}</span>}
            </button>
            <div className="w-8 h-8 bg-sky-500 rounded-xl flex items-center justify-center text-white text-sm font-bold">
              {user?.name?.[0] || 'A'}
            </div>
          </div>
        </header>
        <main className="flex-1 overflow-y-auto p-6">
          <Outlet />
        </main>
      </div>
    </div>
  )
}
