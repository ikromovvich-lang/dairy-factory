import React, { useState, useEffect } from 'react'
import { farmerAPI } from '../../services/api'
import { Plus, Phone, MapPin } from 'lucide-react'
import toast from 'react-hot-toast'

export default function FarmersPage() {
  const [farmers, setFarmers] = useState([])
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState({ name:'',phone:'',location:'',price_per_liter:'3800',bank_account:'',notes:'' })
  const [loading, setLoading] = useState(false)

  useEffect(() => { farmerAPI.getAll().then(setFarmers).catch(()=>{}) }, [])

  const submit = async (e) => {
    e.preventDefault(); setLoading(true)
    try { await farmerAPI.create(form); toast.success('Fermer qo\'shildi!'); setShowForm(false); setForm({ name:'',phone:'',location:'',price_per_liter:'3800',bank_account:'',notes:'' }); farmerAPI.getAll().then(setFarmers) }
    catch (err) { toast.error(err.error || 'Xatolik') }
    finally { setLoading(false) }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div><h1 className="text-2xl font-bold text-slate-800 font-display">Fermerlar</h1><p className="text-slate-500 text-sm">{farmers.length} ta faol fermer</p></div>
        <button onClick={() => setShowForm(true)} className="btn-primary text-sm"><Plus size={16}/>Yangi fermer</button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {farmers.map(f => (
          <div key={f.id} className="card card-hover p-5">
            <div className="flex items-start justify-between mb-3">
              <div className="w-10 h-10 bg-sky-100 rounded-xl flex items-center justify-center text-sky-600 font-bold text-lg">{f.name[0]}</div>
              <span className="badge-green text-xs">{f.is_active ? 'Faol' : 'Nofaol'}</span>
            </div>
            <h3 className="font-bold text-slate-800">{f.name}</h3>
            <div className="mt-2 space-y-1.5 text-sm text-slate-500">
              <div className="flex items-center gap-2"><Phone size={13}/>{f.phone}</div>
              <div className="flex items-center gap-2"><MapPin size={13}/><span className="truncate">{f.location}</span></div>
            </div>
            <div className="mt-3 pt-3 border-t border-slate-100 flex justify-between text-sm">
              <div><p className="text-xs text-slate-400">Narx/L</p><p className="font-bold text-emerald-600">{Number(f.price_per_liter).toLocaleString()} so'm</p></div>
              <div className="text-right"><p className="text-xs text-slate-400">Jami yetkazildi</p><p className="font-bold text-slate-800">{parseFloat(f.total_delivered||0).toFixed(0)}L</p></div>
            </div>
          </div>
        ))}
      </div>
      {showForm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={()=>setShowForm(false)}>
          <div className="card max-w-md w-full p-6 animate-in" onClick={e=>e.stopPropagation()}>
            <h3 className="section-title mb-4">Yangi fermer qo'shish</h3>
            <form onSubmit={submit} className="space-y-3">
              {[['name','Ism familiya','text'],['phone','Telefon','+998...'],['location','Manzil','Tuman, ko\'cha'],['price_per_liter','Narx (so\'m/L)','3800'],['bank_account','Bank hisob raqami','']].map(([f,l,p])=>(
                <div key={f}><label className="label">{l}</label><input value={form[f]} onChange={e=>setForm({...form,[f]:e.target.value})} className="input" placeholder={p} required={['name','phone','location'].includes(f)} /></div>
              ))}
              <div><label className="label">Izoh</label><textarea value={form.notes} onChange={e=>setForm({...form,notes:e.target.value})} className="input resize-none" rows={2} /></div>
              <div className="flex gap-2 pt-2">
                <button type="button" onClick={()=>setShowForm(false)} className="btn-secondary flex-1 justify-center">Bekor</button>
                <button type="submit" disabled={loading} className="btn-primary flex-1 justify-center">{loading?'...':'Saqlash'}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
