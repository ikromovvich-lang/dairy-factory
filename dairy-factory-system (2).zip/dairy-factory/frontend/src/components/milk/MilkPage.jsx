import React, { useState, useEffect } from 'react';
import { milkAPI, farmersAPI } from '../../services/api';
import toast from 'react-hot-toast';
import { format } from 'date-fns';

const GRADES = [
  { value: 'premium', label: '⭐ Premium', color: 'bg-yellow-100 text-yellow-700' },
  { value: 'first', label: '✅ Birinchi', color: 'bg-green-100 text-green-700' },
  { value: 'second', label: '⚠️ Ikkinchi', color: 'bg-orange-100 text-orange-700' },
  { value: 'rejected', label: '❌ Rad etilgan', color: 'bg-red-100 text-red-700' }
];

const fmtMoney = n => Number(n).toLocaleString('uz-UZ');

export default function MilkPage() {
  const [collections, setCollections] = useState([]);
  const [farmers, setFarmers] = useState([]);
  const [dailyReport, setDailyReport] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('list');
  const [form, setForm] = useState({
    farmer_id: '', liters: '', fat_percentage: '3.2', protein_percentage: '3.2',
    temperature: '4', quality_grade: 'first', notes: ''
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [cols, fms, report] = await Promise.all([
        milkAPI.getAll({ limit: 50 }),
        farmersAPI.getAll(),
        milkAPI.getDailyReport()
      ]);
      setCollections(cols.data.data);
      setFarmers(fms.data);
      setDailyReport(report.data);
    } catch {}
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await milkAPI.create(form);
      toast.success('✅ Sut muvaffaqiyatli qabul qilindi!');
      setShowForm(false);
      setForm({ farmer_id: '', liters: '', fat_percentage: '3.2', protein_percentage: '3.2', temperature: '4', quality_grade: 'first', notes: '' });
      fetchData();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Xatolik yuz berdi');
    } finally {
      setLoading(false);
    }
  };

  const today = dailyReport?.summary || {};

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">🥛 Sut Qabul Boshqaruvi</h1>
          <p className="text-slate-500 text-sm mt-1">Fermerlardan sut qabul qilish va to'lovlar</p>
        </div>
        <button onClick={() => setShowForm(!showForm)}
          className="px-5 py-2.5 rounded-xl font-semibold text-white text-sm transition"
          style={{background: 'linear-gradient(135deg,#1e3a5f,#0ea5e9)'}}>
          + Sut qabul qilish
        </button>
      </div>

      {/* Today Summary */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { icon: '🥛', label: 'Bugun qabul', value: `${Number(today.total_liters || 0).toFixed(0)}L` },
          { icon: '💰', label: "To'lov", value: `${fmtMoney(today.total_payment || 0)} so'm` },
          { icon: '🧪', label: 'O\'rtacha yog\'lik', value: `${Number(today.avg_fat || 0).toFixed(2)}%` },
          { icon: '📦', label: 'Yetkazmalar', value: today.count || 0 },
        ].map((kpi) => (
          <div key={kpi.label} className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100">
            <div className="text-2xl mb-2">{kpi.icon}</div>
            <p className="text-xs text-slate-500 font-medium">{kpi.label}</p>
            <p className="text-xl font-bold text-slate-800 mt-1">{kpi.value}</p>
          </div>
        ))}
      </div>

      {/* Add Form */}
      {showForm && (
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-blue-100">
          <h3 className="font-bold text-slate-800 mb-4">📝 Yangi Sut Qabul</h3>
          <form onSubmit={handleSubmit} className="grid grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">Fermer *</label>
              <select value={form.farmer_id} onChange={e => setForm({...form, farmer_id: e.target.value})}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 outline-none focus:border-blue-400 text-sm" required>
                <option value="">-- Fermer tanlang --</option>
                {farmers.map(f => <option key={f.id} value={f.id}>{f.name} — {f.location}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">Litr *</label>
              <input type="number" value={form.liters} onChange={e => setForm({...form, liters: e.target.value})}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 outline-none focus:border-blue-400 text-sm"
                placeholder="e.g. 150" min="1" step="0.1" required />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">Yog'lik % *</label>
              <input type="number" value={form.fat_percentage} onChange={e => setForm({...form, fat_percentage: e.target.value})}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 outline-none focus:border-blue-400 text-sm"
                placeholder="3.2" min="2.5" max="8" step="0.1" required />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">Oqsil %</label>
              <input type="number" value={form.protein_percentage} onChange={e => setForm({...form, protein_percentage: e.target.value})}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 outline-none focus:border-blue-400 text-sm"
                placeholder="3.2" step="0.1" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">Harorat °C</label>
              <input type="number" value={form.temperature} onChange={e => setForm({...form, temperature: e.target.value})}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 outline-none focus:border-blue-400 text-sm"
                placeholder="4" step="0.1" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">Sifat darajasi *</label>
              <select value={form.quality_grade} onChange={e => setForm({...form, quality_grade: e.target.value})}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 outline-none focus:border-blue-400 text-sm" required>
                {GRADES.map(g => <option key={g.value} value={g.value}>{g.label}</option>)}
              </select>
            </div>
            <div className="lg:col-span-2">
              <label className="block text-xs font-semibold text-slate-600 mb-1">Izoh</label>
              <input type="text" value={form.notes} onChange={e => setForm({...form, notes: e.target.value})}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 outline-none focus:border-blue-400 text-sm"
                placeholder="Qo'shimcha ma'lumot..." />
            </div>
            <div className="flex gap-3 items-end">
              <button type="submit" disabled={loading}
                className="flex-1 py-2.5 rounded-xl font-semibold text-white text-sm transition"
                style={{background: 'linear-gradient(135deg,#1e3a5f,#0ea5e9)'}}>
                {loading ? '⏳...' : '✅ Saqlash'}
              </button>
              <button type="button" onClick={() => setShowForm(false)}
                className="px-4 py-2.5 rounded-xl border border-slate-200 text-slate-600 text-sm hover:bg-slate-50 transition">
                Bekor
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Collections Table */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-5 border-b border-slate-100">
          <h3 className="font-bold text-slate-800">📋 So'nggi Qabullar</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-50 text-slate-600 text-xs font-semibold uppercase tracking-wider">
                <th className="px-4 py-3 text-left">Fermer</th>
                <th className="px-4 py-3 text-right">Litr</th>
                <th className="px-4 py-3 text-right">Yog'lik</th>
                <th className="px-4 py-3 text-center">Sifat</th>
                <th className="px-4 py-3 text-right">To'lov</th>
                <th className="px-4 py-3 text-center">Holat</th>
                <th className="px-4 py-3 text-right">Sana</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {collections.map(c => {
                const grade = GRADES.find(g => g.value === c.quality_grade);
                return (
                  <tr key={c.id} className="hover:bg-slate-50 transition">
                    <td className="px-4 py-3">
                      <div className="font-medium text-slate-800">{c.Farmer?.name}</div>
                      <div className="text-xs text-slate-400">{c.Farmer?.location}</div>
                    </td>
                    <td className="px-4 py-3 text-right font-semibold text-slate-700">{c.liters}L</td>
                    <td className="px-4 py-3 text-right text-slate-600">{c.fat_percentage}%</td>
                    <td className="px-4 py-3 text-center">
                      <span className={`text-xs px-2 py-1 rounded-lg font-medium ${grade?.color}`}>{grade?.label}</span>
                    </td>
                    <td className="px-4 py-3 text-right font-semibold text-green-700">{fmtMoney(c.total_payment)} so'm</td>
                    <td className="px-4 py-3 text-center">
                      <span className={`text-xs px-2 py-1 rounded-lg font-medium ${c.is_paid ? 'bg-green-100 text-green-700' : 'bg-orange-100 text-orange-600'}`}>
                        {c.is_paid ? "✓ To'landi" : "⏳ Kutilmoqda"}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right text-slate-400 text-xs">
                      {format(new Date(c.created_at), 'dd/MM HH:mm')}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {collections.length === 0 && (
            <div className="text-center py-12 text-slate-400">
              <div className="text-4xl mb-2">🥛</div>
              <p>Hali sut qabul qilinmagan</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
