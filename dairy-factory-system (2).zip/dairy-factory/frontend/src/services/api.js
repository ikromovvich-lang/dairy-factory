import axios from 'axios';

const BASE = import.meta.env.VITE_API_URL || '';

const api = axios.create({ baseURL: `${BASE}/api`, timeout: 30000 });

api.interceptors.request.use(cfg => {
  const token = localStorage.getItem('dairy_token');
  if (token) cfg.headers.Authorization = `Bearer ${token}`;
  return cfg;
});

api.interceptors.response.use(
  r => r.data,
  err => {
    if (err.response?.status === 401) {
      localStorage.removeItem('dairy_token');
      localStorage.removeItem('dairy_user');
      window.location.href = '/login';
    }
    return Promise.reject(err.response?.data || err);
  }
);

export default api;

// Auth
export const authAPI = {
  login: (d) => api.post('/auth/login', d),
  me: () => api.get('/auth/me'),
  register: (d) => api.post('/auth/register', d),
  changePassword: (d) => api.put('/auth/change-password', d),
};

// Dashboard
export const dashboardAPI = {
  overview: () => api.get('/dashboard/overview'),
  charts: (days) => api.get('/dashboard/charts', { params: { days } }),
};

// Milk
export const milkAPI = {
  create: (d) => api.post('/milk', d),
  getAll: (p) => api.get('/milk', { params: p }),
  dailyReport: (date) => api.get('/milk/daily-report', { params: { date } }),
  stats: (days) => api.get('/milk/stats', { params: { days } }),
  markPaid: (d) => api.post('/milk/mark-paid', d),
};

// Farmers
export const farmerAPI = {
  getAll: () => api.get('/farmers'),
  create: (d) => api.post('/farmers', d),
  update: (id, d) => api.put(`/farmers/${id}`, d),
  getSummary: (id) => api.get(`/farmers/${id}/summary`),
};

// Production
export const productionAPI = {
  createBatch: (d) => api.post('/production/batches', d),
  completeBatch: (id, d) => api.put(`/production/batches/${id}/complete`, d),
  getBatches: (p) => api.get('/production/batches', { params: p }),
  getStats: (days) => api.get('/production/batches/stats', { params: { days } }),
  getRecipes: () => api.get('/production/recipes'),
  getQR: (batchId) => `${BASE}/api/production/qr/${batchId}`,
};

// Inventory
export const inventoryAPI = {
  getAll: (p) => api.get('/inventory', { params: p }),
  getSummary: () => api.get('/inventory/summary'),
  adjust: (id, d) => api.put(`/inventory/${id}/adjust`, d),
};

// Sales
export const salesAPI = {
  createOrder: (d) => api.post('/sales/orders', d),
  getOrders: (p) => api.get('/sales/orders', { params: p }),
  dailyRevenue: (days) => api.get('/sales/revenue/daily', { params: { days } }),
  byProduct: (days) => api.get('/sales/revenue/by-product', { params: { days } }),
};

// Customers
export const customerAPI = {
  getAll: () => api.get('/customers'),
  create: (d) => api.post('/customers', d),
  update: (id, d) => api.put(`/customers/${id}`, d),
};

// Alerts
export const alertAPI = {
  getAll: (p) => api.get('/alerts', { params: p }),
  markRead: (id) => api.put(`/alerts/${id}/read`),
  readAll: () => api.put('/alerts/read-all'),
  resolve: (id) => api.put(`/alerts/${id}/resolve`),
};

// Analytics
export const analyticsAPI = {
  getPredictions: () => api.get('/analytics/predictions'),
  requestForecast: () => api.post('/analytics/forecast'),
  getTips: () => api.get('/analytics/optimization-tips'),
};
