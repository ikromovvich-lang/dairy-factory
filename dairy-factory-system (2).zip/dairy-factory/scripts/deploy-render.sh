#!/bin/bash
# ============================================================
# Deploy to Render.com using render.yaml
# ============================================================
echo "🎯 Creating render.yaml for Render deployment..."

cat > /home/claude/dairy-factory/render.yaml << 'YAML'
services:
  - type: web
    name: dairy-backend
    env: node
    region: frankfurt
    plan: starter
    rootDir: backend
    buildCommand: npm ci
    startCommand: node src/server.js
    envVars:
      - key: NODE_ENV
        value: production
      - key: DATABASE_URL
        fromDatabase:
          name: dairy-postgres
          property: connectionString
      - key: JWT_SECRET
        generateValue: true
      - key: AI_SERVICE_URL
        value: https://dairy-ai.onrender.com

  - type: web
    name: dairy-ai
    env: python
    region: frankfurt
    plan: starter
    rootDir: ai-service
    buildCommand: pip install -r requirements.txt
    startCommand: python main.py
    envVars:
      - key: DATABASE_URL
        fromDatabase:
          name: dairy-postgres
          property: connectionString

  - type: web
    name: dairy-frontend
    env: static
    region: frankfurt
    rootDir: frontend
    buildCommand: npm ci && npm run build
    staticPublishPath: ./dist
    envVars:
      - key: VITE_API_URL
        value: https://dairy-backend.onrender.com
      - key: VITE_WS_URL
        value: wss://dairy-backend.onrender.com

databases:
  - name: dairy-postgres
    databaseName: dairy_factory
    user: dairy_admin
    region: frankfurt
    plan: starter
YAML

echo "✅ render.yaml created! Push to GitHub and connect at render.com"
