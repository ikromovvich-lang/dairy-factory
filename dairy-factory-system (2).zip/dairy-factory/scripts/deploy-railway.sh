#!/bin/bash
# ============================================================
# Deploy to Railway.app
# ============================================================
echo "🚂 Deploying Dairy Factory to Railway..."

# Install Railway CLI
if ! command -v railway &> /dev/null; then
    curl -fsSL https://railway.app/install.sh | sh
fi

railway login

# Deploy Backend
echo "📦 Deploying Backend..."
cd backend
railway init --name dairy-backend
railway add --database postgresql
railway add --database redis
railway up --service dairy-backend

# Deploy AI Service
echo "🧠 Deploying AI Service..."
cd ../ai-service
railway init --name dairy-ai
railway up --service dairy-ai

# Deploy Frontend
echo "🎨 Deploying Frontend..."
cd ../frontend
railway init --name dairy-frontend
railway up --service dairy-frontend

echo "✅ Deployment complete!"
