-- ============================================================
-- DAIRY FACTORY MANAGEMENT SYSTEM - DATABASE SCHEMA v1.0
-- ============================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

-- ENUMS
CREATE TYPE user_role AS ENUM ('admin', 'manager', 'worker');
CREATE TYPE quality_grade AS ENUM ('premium', 'first', 'second', 'rejected');
CREATE TYPE product_type AS ENUM ('milk', 'yogurt', 'tvorog', 'smetana');
CREATE TYPE batch_status AS ENUM ('planned', 'in_progress', 'completed', 'failed', 'recalled');
CREATE TYPE sale_status AS ENUM ('pending', 'confirmed', 'delivered', 'cancelled');
CREATE TYPE customer_type AS ENUM ('shop', 'distributor', 'restaurant', 'individual');
CREATE TYPE alert_type AS ENUM ('low_stock', 'expiring_soon', 'out_of_stock', 'quality_issue', 'low_milk', 'system');
CREATE TYPE alert_severity AS ENUM ('info', 'warning', 'critical');

-- ============================================================
-- USERS TABLE
-- ============================================================
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(20),
    password_hash VARCHAR(255) NOT NULL,
    role user_role NOT NULL DEFAULT 'worker',
    factory_id UUID,
    is_active BOOLEAN DEFAULT true,
    last_login TIMESTAMPTZ,
    avatar_url VARCHAR(500),
    refresh_token_hash VARCHAR(255),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- FACTORIES TABLE (multi-tenant support)
-- ============================================================
CREATE TABLE factories (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(200) NOT NULL,
    location VARCHAR(500),
    license_number VARCHAR(100),
    capacity_liters_per_day INTEGER DEFAULT 10000,
    is_active BOOLEAN DEFAULT true,
    settings JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE users ADD CONSTRAINT fk_user_factory
    FOREIGN KEY (factory_id) REFERENCES factories(id);

-- ============================================================
-- FARMERS TABLE
-- ============================================================
CREATE TABLE farmers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    factory_id UUID NOT NULL REFERENCES factories(id),
    name VARCHAR(150) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    location VARCHAR(300),
    bank_account VARCHAR(50),
    price_per_liter DECIMAL(10,2) DEFAULT 3500.00,
    is_active BOOLEAN DEFAULT true,
    total_delivered DECIMAL(12,2) DEFAULT 0,
    total_paid DECIMAL(14,2) DEFAULT 0,
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- MILK COLLECTIONS TABLE
-- ============================================================
CREATE TABLE milk_collections (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    factory_id UUID NOT NULL REFERENCES factories(id),
    farmer_id UUID NOT NULL REFERENCES farmers(id),
    collection_date DATE NOT NULL DEFAULT CURRENT_DATE,
    liters DECIMAL(10,2) NOT NULL CHECK (liters > 0),
    fat_percentage DECIMAL(4,2) NOT NULL CHECK (fat_percentage BETWEEN 2.5 AND 8.0),
    protein_percentage DECIMAL(4,2) DEFAULT 3.2,
    temperature DECIMAL(4,1),
    quality_grade quality_grade NOT NULL,
    price_per_liter DECIMAL(10,2) NOT NULL,
    total_payment DECIMAL(12,2) GENERATED ALWAYS AS (liters * price_per_liter) STORED,
    is_paid BOOLEAN DEFAULT false,
    paid_at TIMESTAMPTZ,
    notes TEXT,
    recorded_by UUID REFERENCES users(id),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- PRODUCT RECIPES TABLE
-- ============================================================
CREATE TABLE product_recipes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    factory_id UUID NOT NULL REFERENCES factories(id),
    product_type product_type NOT NULL,
    product_name VARCHAR(200) NOT NULL,
    milk_per_unit DECIMAL(8,3) NOT NULL COMMENT_PLACEHOLDER,
    unit VARCHAR(20) DEFAULT 'kg',
    yield_percentage DECIMAL(5,2) DEFAULT 85.00,
    min_fat_required DECIMAL(4,2) DEFAULT 3.2,
    processing_hours INTEGER DEFAULT 4,
    shelf_life_days INTEGER NOT NULL,
    price_per_unit DECIMAL(10,2) NOT NULL,
    description TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Remove comment placeholder
COMMENT ON COLUMN product_recipes.milk_per_unit IS 'Liters of milk needed to produce 1 unit';

-- ============================================================
-- PRODUCTION BATCHES TABLE
-- ============================================================
CREATE TABLE production_batches (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    factory_id UUID NOT NULL REFERENCES factories(id),
    batch_id VARCHAR(20) UNIQUE NOT NULL,
    recipe_id UUID NOT NULL REFERENCES product_recipes(id),
    product_type product_type NOT NULL,
    product_name VARCHAR(200) NOT NULL,
    status batch_status DEFAULT 'planned',
    production_date DATE NOT NULL DEFAULT CURRENT_DATE,
    expiration_date DATE NOT NULL,
    milk_used_liters DECIMAL(10,2) NOT NULL,
    quantity_produced DECIMAL(10,2),
    quantity_planned DECIMAL(10,2) NOT NULL,
    yield_actual DECIMAL(5,2),
    fat_percentage DECIMAL(4,2),
    quality_score INTEGER CHECK (quality_score BETWEEN 1 AND 100),
    qr_code_url VARCHAR(500),
    qr_code_data TEXT,
    notes TEXT,
    started_by UUID REFERENCES users(id),
    completed_by UUID REFERENCES users(id),
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- INVENTORY TABLE
-- ============================================================
CREATE TABLE inventory (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    factory_id UUID NOT NULL REFERENCES factories(id),
    product_type product_type NOT NULL,
    product_name VARCHAR(200) NOT NULL,
    batch_id UUID REFERENCES production_batches(id),
    quantity DECIMAL(12,2) NOT NULL DEFAULT 0,
    unit VARCHAR(20) DEFAULT 'kg',
    min_stock_alert DECIMAL(10,2) DEFAULT 50,
    expiration_date DATE,
    location VARCHAR(100) DEFAULT 'Main Warehouse',
    price_per_unit DECIMAL(10,2),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(factory_id, product_type, batch_id)
);

-- ============================================================
-- CUSTOMERS TABLE
-- ============================================================
CREATE TABLE customers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    factory_id UUID NOT NULL REFERENCES factories(id),
    name VARCHAR(200) NOT NULL,
    type customer_type NOT NULL DEFAULT 'shop',
    phone VARCHAR(20),
    email VARCHAR(255),
    address VARCHAR(500),
    tin_number VARCHAR(50),
    credit_limit DECIMAL(14,2) DEFAULT 0,
    current_balance DECIMAL(14,2) DEFAULT 0,
    discount_percentage DECIMAL(5,2) DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    total_purchases DECIMAL(16,2) DEFAULT 0,
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- SALES ORDERS TABLE
-- ============================================================
CREATE TABLE sales_orders (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    factory_id UUID NOT NULL REFERENCES factories(id),
    order_number VARCHAR(20) UNIQUE NOT NULL,
    customer_id UUID NOT NULL REFERENCES customers(id),
    status sale_status DEFAULT 'pending',
    order_date DATE NOT NULL DEFAULT CURRENT_DATE,
    delivery_date DATE,
    subtotal DECIMAL(14,2) DEFAULT 0,
    discount_amount DECIMAL(12,2) DEFAULT 0,
    tax_amount DECIMAL(12,2) DEFAULT 0,
    total_amount DECIMAL(14,2) DEFAULT 0,
    paid_amount DECIMAL(14,2) DEFAULT 0,
    notes TEXT,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- SALE ORDER ITEMS TABLE
-- ============================================================
CREATE TABLE sale_order_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_id UUID NOT NULL REFERENCES sales_orders(id) ON DELETE CASCADE,
    product_type product_type NOT NULL,
    product_name VARCHAR(200) NOT NULL,
    batch_id UUID REFERENCES production_batches(id),
    quantity DECIMAL(10,2) NOT NULL CHECK (quantity > 0),
    unit VARCHAR(20) DEFAULT 'kg',
    unit_price DECIMAL(10,2) NOT NULL,
    discount_percentage DECIMAL(5,2) DEFAULT 0,
    total_price DECIMAL(12,2) GENERATED ALWAYS AS (
        quantity * unit_price * (1 - discount_percentage / 100)
    ) STORED
);

-- ============================================================
-- ALERTS TABLE
-- ============================================================
CREATE TABLE alerts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    factory_id UUID NOT NULL REFERENCES factories(id),
    type alert_type NOT NULL,
    severity alert_severity NOT NULL DEFAULT 'warning',
    title VARCHAR(300) NOT NULL,
    message TEXT NOT NULL,
    related_id UUID,
    related_type VARCHAR(50),
    is_read BOOLEAN DEFAULT false,
    is_resolved BOOLEAN DEFAULT false,
    read_by UUID REFERENCES users(id),
    resolved_by UUID REFERENCES users(id),
    resolved_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- AI PREDICTIONS TABLE
-- ============================================================
CREATE TABLE ai_predictions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    factory_id UUID NOT NULL REFERENCES factories(id),
    prediction_type VARCHAR(50) NOT NULL,
    product_type product_type,
    prediction_date DATE NOT NULL,
    predicted_value DECIMAL(14,2) NOT NULL,
    confidence_score DECIMAL(5,2),
    actual_value DECIMAL(14,2),
    model_version VARCHAR(20),
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- AUDIT LOG TABLE
-- ============================================================
CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    factory_id UUID,
    user_id UUID REFERENCES users(id),
    action VARCHAR(100) NOT NULL,
    table_name VARCHAR(100),
    record_id UUID,
    old_values JSONB,
    new_values JSONB,
    ip_address INET,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- INDEXES FOR PERFORMANCE
-- ============================================================
CREATE INDEX idx_milk_collections_date ON milk_collections(collection_date DESC);
CREATE INDEX idx_milk_collections_farmer ON milk_collections(farmer_id);
CREATE INDEX idx_milk_collections_factory ON milk_collections(factory_id);
CREATE INDEX idx_batches_date ON production_batches(production_date DESC);
CREATE INDEX idx_batches_expiry ON production_batches(expiration_date);
CREATE INDEX idx_batches_status ON production_batches(status);
CREATE INDEX idx_inventory_factory ON inventory(factory_id);
CREATE INDEX idx_inventory_expiry ON inventory(expiration_date);
CREATE INDEX idx_sales_date ON sales_orders(order_date DESC);
CREATE INDEX idx_sales_customer ON sales_orders(customer_id);
CREATE INDEX idx_alerts_factory ON alerts(factory_id, is_read);
CREATE INDEX idx_predictions_date ON ai_predictions(prediction_date);

-- ============================================================
-- SEED DATA
-- ============================================================

-- Default Factory
INSERT INTO factories (id, name, location, capacity_liters_per_day) VALUES
('00000000-0000-0000-0000-000000000001', 'SutMahsulot Zavodi #1', 'Toshkent viloyati, Yangiyo''l tumani', 15000);

-- Default Admin User (password: Admin@2024!)
INSERT INTO users (name, email, password_hash, role, factory_id) VALUES
('System Admin', 'admin@dairy.uz', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TiGniMGCb7n7AeKLc.Lm0qNX2AuO', 'admin', '00000000-0000-0000-0000-000000000001'),
('Plant Manager', 'manager@dairy.uz', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TiGniMGCb7n7AeKLc.Lm0qNX2AuO', 'manager', '00000000-0000-0000-0000-000000000001');

-- Product Recipes
INSERT INTO product_recipes (factory_id, product_type, product_name, milk_per_unit, yield_percentage, shelf_life_days, price_per_unit, processing_hours) VALUES
('00000000-0000-0000-0000-000000000001', 'milk', 'Pasterizatsiya qilingan sut 2.5%', 1.05, 95.0, 7, 6500, 2),
('00000000-0000-0000-0000-000000000001', 'milk', 'Pasterizatsiya qilingan sut 3.2%', 1.05, 95.0, 7, 7000, 2),
('00000000-0000-0000-0000-000000000001', 'yogurt', 'Yogurt klassik 3.2%', 1.15, 87.0, 14, 12000, 8),
('00000000-0000-0000-0000-000000000001', 'yogurt', 'Yogurt mevalik', 1.20, 83.0, 14, 14000, 10),
('00000000-0000-0000-0000-000000000001', 'tvorog', 'Tvorog 5%', 8.50, 11.0, 5, 35000, 12),
('00000000-0000-0000-0000-000000000001', 'tvorog', 'Tvorog 9%', 9.00, 10.5, 5, 42000, 14),
('00000000-0000-0000-0000-000000000001', 'smetana', 'Smetana 20%', 4.20, 22.0, 14, 28000, 6),
('00000000-0000-0000-0000-000000000001', 'smetana', 'Smetana 25%', 5.00, 18.5, 14, 34000, 6);

-- Sample Farmers
INSERT INTO farmers (factory_id, name, phone, location, price_per_liter) VALUES
('00000000-0000-0000-0000-000000000001', 'Karimov Baxtiyor', '+998901234567', 'Yangiyo''l, Bog''bon ko''chasi 12', 3800.00),
('00000000-0000-0000-0000-000000000001', 'Toshmatov Sardor', '+998912345678', 'Chinoz tumani, Yangi hayot MFY', 3700.00),
('00000000-0000-0000-0000-000000000001', 'Rahimova Nafisa', '+998923456789', 'Qibray tumani, Eski shahar', 3900.00),
('00000000-0000-0000-0000-000000000001', 'Yusupov Alisher', '+998934567890', 'Bo''stonliq tumani, Ko''ksaroy', 3750.00),
('00000000-0000-0000-0000-000000000001', 'Mirzaev Jasur', '+998945678901', 'Zangiota tumani, Olmosoy', 3850.00);

-- Sample Customers
INSERT INTO customers (factory_id, name, type, phone, address, discount_percentage) VALUES
('00000000-0000-0000-0000-000000000001', 'Korzinka.uz', 'shop', '+998712345678', 'Toshkent sh., Mirzo Ulug''bek tumani', 5.0),
('00000000-0000-0000-0000-000000000001', 'Makro Supermarket', 'shop', '+998712345679', 'Toshkent sh., Chilonzor tumani', 5.0),
('00000000-0000-0000-0000-000000000001', 'Fresh Food Distribution', 'distributor', '+998712345680', 'Toshkent sh., Sergeli tumani', 8.0),
('00000000-0000-0000-0000-000000000001', 'Furkat restoran', 'restaurant', '+998712345681', 'Toshkent sh., Yakkasaroy', 3.0),
('00000000-0000-0000-0000-000000000001', 'Oilaviy Bozor', 'shop', '+998712345682', 'Toshkent sh., Uchtepa tumani', 2.0);

-- ============================================================
-- FUNCTIONS & TRIGGERS
-- ============================================================

-- Auto-update updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_farmers_updated_at BEFORE UPDATE ON farmers
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_batches_updated_at BEFORE UPDATE ON production_batches
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_customers_updated_at BEFORE UPDATE ON customers
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_sales_updated_at BEFORE UPDATE ON sales_orders
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Generate Batch ID
CREATE OR REPLACE FUNCTION generate_batch_id()
RETURNS VARCHAR AS $$
DECLARE
    prefix VARCHAR := 'BAT';
    date_part VARCHAR := TO_CHAR(NOW(), 'YYMMDD');
    seq INTEGER;
    batch_id VARCHAR;
BEGIN
    SELECT COALESCE(MAX(CAST(SUBSTRING(b.batch_id FROM 10) AS INTEGER)), 0) + 1
    INTO seq FROM production_batches b
    WHERE b.batch_id LIKE prefix || date_part || '%';
    
    batch_id := prefix || date_part || LPAD(seq::VARCHAR, 4, '0');
    RETURN batch_id;
END;
$$ LANGUAGE plpgsql;

-- Generate Order Number
CREATE OR REPLACE FUNCTION generate_order_number()
RETURNS VARCHAR AS $$
DECLARE
    prefix VARCHAR := 'ORD';
    date_part VARCHAR := TO_CHAR(NOW(), 'YYMMDD');
    seq INTEGER;
BEGIN
    SELECT COALESCE(MAX(CAST(SUBSTRING(o.order_number FROM 10) AS INTEGER)), 0) + 1
    INTO seq FROM sales_orders o
    WHERE o.order_number LIKE prefix || date_part || '%';
    RETURN prefix || date_part || LPAD(seq::VARCHAR, 4, '0');
END;
$$ LANGUAGE plpgsql;
