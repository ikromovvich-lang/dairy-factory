# 🥛 SutMahsulot — Dairy Factory Management System

> **Premium AI-powered ERP for milk processing plants** — Production-ready, scalable, real-time

---

## 🏗️ Architecture Overview

```
dairy-factory/
├── backend/          # Node.js + Express + PostgreSQL
│   └── src/
│       ├── config/        # DB + Redis config
│       ├── controllers/   # Business logic
│       ├── middleware/     # Auth, rate limiting
│       ├── models/        # Sequelize ORM models
│       ├── routes/        # Express routers
│       ├── services/      # Socket.io, alerts, AI
│       └── server.js      # Entry point
├── frontend/         # React + Tailwind CSS
│   └── src/
│       ├── components/    # All UI pages
│       ├── hooks/         # useSocket (real-time)
│       ├── services/      # Axios API client
│       ├── store/         # Zustand global state
│       └── App.jsx
├── ai-service/       # Python FastAPI AI microservice
│   └── main.py       # Prophet/sklearn forecasting
├── scripts/          # DB init, deployment scripts
└── docker-compose.yml
```

---

## 🚀 Quick Start (Local)

### Prerequisites
- Node.js 18+, Python 3.11+, PostgreSQL 15+, Redis 7+

### 1. Clone & Setup

```bash
git clone <repo>
cd dairy-factory
cp .env.example .env
# Edit .env with your values
```

### 2. Database Setup

```bash
# Create DB and run schema
psql -U postgres -c "CREATE USER dairy_admin WITH PASSWORD 'DairySecure2024!';"
psql -U postgres -c "CREATE DATABASE dairy_factory OWNER dairy_admin;"
psql -U dairy_admin -d dairy_factory -f scripts/init.sql
```

### 3. Backend

```bash
cd backend
npm install
node src/server.js
# API runs on http://localhost:3001
```

### 4. AI Service

```bash
cd ai-service
pip install -r requirements.txt
python main.py
# AI runs on http://localhost:8001
```

### 5. Frontend

```bash
cd frontend
npm install
npm run dev
# UI runs on http://localhost:5173
```

---

## 🐳 Docker (Recommended)

```bash
# Copy and configure environment
cp .env.example .env

# Start everything
docker-compose up -d

# View logs
docker-compose logs -f backend

# Stop
docker-compose down
```

Services:
- Frontend: http://localhost:3000
- Backend API: http://localhost:3001
- AI Service: http://localhost:8001
- PostgreSQL: localhost:5432
- Redis: localhost:6379

---

## ☁️ Cloud Deployment

### Railway.app (Fastest)

```bash
bash scripts/deploy-railway.sh
```

### Render.com

```bash
bash scripts/deploy-render.sh
# Then push to GitHub and connect repo at render.com
# render.yaml handles everything automatically
```

### Vercel (Frontend only)

```bash
cd frontend
npx vercel --prod
# Set env vars in Vercel dashboard:
# VITE_API_URL=https://your-backend-url
# VITE_WS_URL=wss://your-backend-url
```

---

## 🔐 Default Credentials

| Role    | Email               | Password      |
|---------|---------------------|---------------|
| Admin   | admin@dairy.uz      | Admin@2024!   |
| Manager | manager@dairy.uz    | Admin@2024!   |

---

## 📡 API Endpoints

### Auth
```
POST /api/auth/login         → Login
GET  /api/auth/me            → Current user
POST /api/auth/register      → Register (admin only)
```

### Milk Collection
```
POST /api/milk               → Record milk delivery
GET  /api/milk               → List collections (with pagination)
GET  /api/milk/daily-report  → Daily intake report
GET  /api/milk/stats         → Trend statistics
POST /api/milk/mark-paid     → Mark farmer payments
```

### Production
```
GET  /api/production/recipes          → List recipes
GET  /api/production/batches          → List batches
POST /api/production/batches          → Create batch (auto QR)
PUT  /api/production/batches/:id/complete → Complete batch
GET  /api/production/qr/:batch_id     → Download QR image
```

### Inventory
```
GET  /api/inventory          → Current stock (with expiry alerts)
GET  /api/inventory/summary  → Stock summary by product
PUT  /api/inventory/:id/adjust → Adjust stock level
```

### Sales
```
GET  /api/sales/orders       → List orders
POST /api/sales/orders       → Create order (auto deducts stock)
PUT  /api/sales/orders/:id/status → Update order status
GET  /api/sales/revenue      → Revenue by day
GET  /api/sales/summary      → Revenue KPIs
```

### Analytics (AI)
```
GET  /api/analytics/forecast     → 7-day AI forecast
GET  /api/analytics/efficiency   → Production efficiency metrics
GET  /api/analytics/milk         → Milk quality analytics
GET  /api/analytics/sales        → Sales analytics by product
```

### Farmers & Customers
```
GET  /api/farmers            → All farmers
POST /api/farmers            → Create farmer
GET  /api/farmers/:id/stats  → Farmer delivery history

GET  /api/customers          → All customers
POST /api/customers          → Create customer
```

---

## 🔌 WebSocket Events (Socket.io)

### Server → Client
| Event               | Data                          | Description           |
|---------------------|-------------------------------|-----------------------|
| `new_alert`         | `{type, severity, title, message}` | System alerts    |
| `milk_collected`    | `{farmer, liters, total_today}` | Milk intake       |
| `batch_started`     | `{batch_id, product}`         | Production start      |
| `batch_completed`   | `{batch_id, product, qty}`    | Production complete   |
| `inventory_updated` | `{product_type}`              | Stock change          |
| `new_sale`          | `{order_number, customer, total}` | New order         |
| `stock_alert`       | `{product, qty}`              | Low stock warning     |

---

## 🧠 AI Service Endpoints

```
GET  /health                 → Service health check
POST /predict                → Generate forecasts
POST /optimize-production    → Optimal production allocation
```

### Forecast Response
```json
{
  "milk_forecast": [{"date": "2024-01-15", "predicted_milk": 5400, "confidence": 85}],
  "sales_forecast": [{"product_type": "yogurt", "weekly_forecast": 850, "trend": "up"}],
  "recommendations": [{"type": "production", "message": "...", "priority": "high"}],
  "model": "statistical_v1.0"
}
```

---

## 📊 Database Schema

Key tables:
- `users` — System users with roles
- `factories` — Multi-tenant factory support
- `farmers` — Milk supplier database
- `milk_collections` — Daily milk intake records
- `product_recipes` — Production recipes with yields
- `production_batches` — Batch tracking with QR codes
- `inventory` — Real-time stock levels
- `customers` — Buyer database
- `sales_orders` + `sale_order_items` — Order management
- `alerts` — System notifications
- `ai_predictions` — ML forecast history

---

## 🔒 Security Features

- JWT authentication (24h expiry)
- bcrypt password hashing (12 rounds)
- Rate limiting (500 req/15min global, 20/15min auth)
- Role-based access control (admin/manager/worker)
- Helmet.js security headers
- Input validation on all endpoints
- SQL injection protection via Sequelize ORM
- SSL/TLS support in production

---

## 📱 UI Features

- **Responsive** — Works on tablets (factory floor use)
- **Real-time** — Socket.io live updates without refresh
- **Charts** — Recharts for production/sales/milk trends
- **QR Codes** — Auto-generated per batch, downloadable
- **Dark sidebar** — Compact navigation with icon-only mode
- **Toast alerts** — Instant notifications for all events
- **Uzbek language** — Full UZ localization

---

## 🏭 Production Features by Module

| Module          | Key Features                                              |
|-----------------|-----------------------------------------------------------|
| Milk Collection | Farmer DB, quality grading, auto payment calc, reports    |
| Production      | Batch system, QR codes, yield tracking, recipe management |
| Inventory       | Real-time stock, expiry alerts, low-stock notifications   |
| Sales           | Customer DB, order management, invoice tracking, revenue  |
| AI Analytics    | 7-day forecasts, efficiency radar, quality trends         |
| Notifications   | Socket.io real-time, severity levels, audit trail         |

---

## 📦 Tech Stack Summary

| Layer      | Technology                              |
|------------|-----------------------------------------|
| Frontend   | React 18, Vite, Tailwind CSS, Recharts  |
| State      | Zustand, React Router v6                |
| Backend    | Node.js 20, Express 4, Sequelize 6      |
| Database   | PostgreSQL 15 + Redis 7                 |
| AI Service | Python 3.11, FastAPI, scikit-learn      |
| Real-time  | Socket.io 4                             |
| Security   | JWT, bcrypt, Helmet, rate-limit         |
| DevOps     | Docker, docker-compose, nginx           |
| Deploy     | Railway / Render / Vercel ready         |

---

*SutMahsulot v1.0 — Built for real milk processing plants in Uzbekistan 🇺🇿*
