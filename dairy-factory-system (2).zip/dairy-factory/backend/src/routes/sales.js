const router = require('express').Router();
const c = require('../controllers/salesController');
const { authenticate, authorize } = require('../middleware/auth');

router.use(authenticate);
router.post('/orders', c.createOrder);
router.get('/orders', c.getOrders);
router.get('/revenue/daily', c.getDailyRevenue);
router.get('/revenue/by-product', c.getRevenueByProduct);

module.exports = router;
