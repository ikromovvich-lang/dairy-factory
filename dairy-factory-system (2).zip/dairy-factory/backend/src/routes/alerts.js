const router = require('express').Router();
const { Alert } = require('../models');
const { authenticate, authorize } = require('../middleware/auth');
const { Op } = require('sequelize');

router.use(authenticate);
router.get('/', async (req, res) => {
  const { unread, limit = 50 } = req.query;
  const where = { factory_id: req.factoryId };
  if (unread === 'true') where.is_read = false;
  const alerts = await Alert.findAll({ where, order: [['created_at', 'DESC']], limit: parseInt(limit) });
  res.json(alerts);
});
router.put('/:id/read', async (req, res) => {
  await Alert.update({ is_read: true, read_by: req.user.id }, { where: { id: req.params.id, factory_id: req.factoryId } });
  res.json({ success: true });
});
router.put('/read-all', async (req, res) => {
  await Alert.update({ is_read: true, read_by: req.user.id }, { where: { factory_id: req.factoryId, is_read: false } });
  res.json({ success: true });
});
router.put('/:id/resolve', authorize('admin', 'manager'), async (req, res) => {
  await Alert.update({ is_resolved: true, resolved_by: req.user.id, resolved_at: new Date() }, { where: { id: req.params.id } });
  res.json({ success: true });
});

module.exports = router;
