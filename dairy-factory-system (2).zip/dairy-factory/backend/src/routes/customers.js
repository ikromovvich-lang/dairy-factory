const router = require('express').Router();
const { Customer } = require('../models');
const { authenticate, authorize } = require('../middleware/auth');

router.use(authenticate);
router.get('/', async (req, res) => {
  const customers = await Customer.findAll({ where: { factory_id: req.factoryId }, order: [['name', 'ASC']] });
  res.json(customers);
});
router.post('/', authorize('admin', 'manager'), async (req, res) => {
  try {
    const c = await Customer.create({ ...req.body, factory_id: req.factoryId });
    res.status(201).json(c);
  } catch (err) { res.status(400).json({ error: err.message }); }
});
router.put('/:id', authorize('admin', 'manager'), async (req, res) => {
  const c = await Customer.findOne({ where: { id: req.params.id, factory_id: req.factoryId } });
  if (!c) return res.status(404).json({ error: 'Not found' });
  await c.update(req.body);
  res.json(c);
});

module.exports = router;
