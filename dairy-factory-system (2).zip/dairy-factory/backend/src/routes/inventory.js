const router = require('express').Router();
const c = require('../controllers/inventoryController');
const { authenticate, authorize } = require('../middleware/auth');

router.use(authenticate);
router.get('/', c.getAll);
router.get('/summary', c.getSummary);
router.put('/:id/adjust', authorize('admin', 'manager'), c.adjust);

module.exports = router;
