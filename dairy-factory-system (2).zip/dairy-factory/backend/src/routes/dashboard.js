const router = require('express').Router();
const c = require('../controllers/dashboardController');
const { authenticate } = require('../middleware/auth');

router.use(authenticate);
router.get('/overview', c.getOverview);
router.get('/charts', c.getChartData);

module.exports = router;
