const router = require('express').Router();
const c = require('../controllers/analyticsController');
const { authenticate } = require('../middleware/auth');

router.use(authenticate);
router.get('/predictions', c.getPredictions);
router.post('/forecast', c.requestForecast);
router.get('/optimization-tips', c.getOptimizationTips);

module.exports = router;
