const router = require('express').Router();
const c = require('../controllers/productionController');
const { authenticate, authorize } = require('../middleware/auth');

router.use(authenticate);
router.post('/batches', c.createBatch);
router.put('/batches/:id/complete', c.completeBatch);
router.get('/batches', c.getBatches);
router.get('/batches/stats', c.getStats);
router.get('/qr/:batch_id', c.getQR);
router.get('/recipes', c.getRecipes);

module.exports = router;
