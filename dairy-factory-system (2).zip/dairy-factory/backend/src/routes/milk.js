const router = require('express').Router();
const c = require('../controllers/milkController');
const { authenticate, authorize } = require('../middleware/auth');

router.use(authenticate);
router.post('/', c.create);
router.get('/', c.getAll);
router.get('/daily-report', c.getDailyReport);
router.get('/stats', c.getStats);
router.post('/mark-paid', authorize('admin', 'manager'), c.markPaid);

module.exports = router;
