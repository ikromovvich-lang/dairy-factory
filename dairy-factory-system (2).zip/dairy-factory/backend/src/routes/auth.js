const router = require('express').Router();
const { login, me, register, changePassword } = require('../controllers/authController');
const { authenticate, authorize } = require('../middleware/auth');

router.post('/login', login);
router.get('/me', authenticate, me);
router.post('/register', authenticate, authorize('admin', 'manager'), register);
router.put('/change-password', authenticate, changePassword);

module.exports = router;
