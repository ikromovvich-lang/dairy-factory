const router = require('express').Router();
const { Farmer, MilkCollection, sequelize } = require('../models');
const { authenticate, authorize } = require('../middleware/auth');
const { Op } = require('sequelize');

router.use(authenticate);
router.get('/', async (req, res) => {
  const farmers = await Farmer.findAll({ where: { factory_id: req.factoryId }, order: [['name', 'ASC']] });
  res.json(farmers);
});
router.post('/', authorize('admin', 'manager'), async (req, res) => {
  try {
    const farmer = await Farmer.create({ ...req.body, factory_id: req.factoryId });
    res.status(201).json(farmer);
  } catch (err) { res.status(400).json({ error: err.message }); }
});
router.put('/:id', authorize('admin', 'manager'), async (req, res) => {
  const f = await Farmer.findOne({ where: { id: req.params.id, factory_id: req.factoryId } });
  if (!f) return res.status(404).json({ error: 'Not found' });
  await f.update(req.body);
  res.json(f);
});
router.get('/:id/summary', async (req, res) => {
  const farmer = await Farmer.findOne({ where: { id: req.params.id, factory_id: req.factoryId } });
  if (!farmer) return res.status(404).json({ error: 'Not found' });
  const unpaid = await MilkCollection.sum('total_payment', { where: { farmer_id: req.params.id, is_paid: false } });
  res.json({ ...farmer.toJSON(), unpaid_amount: unpaid || 0 });
});

module.exports = router;
