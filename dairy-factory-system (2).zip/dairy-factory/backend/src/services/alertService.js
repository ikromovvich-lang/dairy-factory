const { Alert } = require('../models');

async function createAlert(factory_id, type, severity, title, message, related_id = null, related_type = null) {
  try {
    // Avoid duplicate alerts (same type + related_id within 1 hour)
    const recent = await Alert.findOne({
      where: { factory_id, type, related_id, is_resolved: false,
        created_at: { [require('sequelize').Op.gte]: new Date(Date.now() - 3600000) } }
    });
    if (recent) return recent;

    const alert = await Alert.create({ factory_id, type, severity, title, message, related_id, related_type });

    if (global.io) {
      global.io.to(`factory:${factory_id}`).emit('new_alert', {
        id: alert.id, type, severity, title, message, created_at: alert.created_at
      });
    }

    return alert;
  } catch (err) {
    console.error('Alert creation failed:', err.message);
  }
}

module.exports = { createAlert };
