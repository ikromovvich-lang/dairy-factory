const { Notification } = require('../models');

const createNotification = async (io, { type, title, message, severity = 'info', targetRole = 'all', metadata = {} }) => {
  try {
    const notification = await Notification.create({ type, title, message, severity, targetRole, metadata });

    if (io) {
      io.emit('notification', {
        id: notification.id,
        type, title, message, severity, metadata,
        createdAt: notification.createdAt
      });
    }

    return notification;
  } catch (err) {
    console.error('Notification error:', err.message);
  }
};

const getNotifications = async (req, res) => {
  try {
    const { unreadOnly, page = 1, limit = 20 } = req.query;
    const where = {};
    if (unreadOnly === 'true') where.isRead = false;

    const { count, rows } = await Notification.findAndCountAll({
      where, limit: parseInt(limit), offset: (page - 1) * limit,
      order: [['createdAt', 'DESC']]
    });

    res.json({ notifications: rows, total: count, unread: await Notification.count({ where: { isRead: false } }) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

const markAsRead = async (req, res) => {
  try {
    const { id } = req.params;
    if (id === 'all') {
      await Notification.update({ isRead: true }, { where: { isRead: false } });
    } else {
      await Notification.update({ isRead: true }, { where: { id } });
    }
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

module.exports = { createNotification, getNotifications, markAsRead };
