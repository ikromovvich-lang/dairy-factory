const jwt = require('jsonwebtoken');
const logger = require('../utils/logger');

module.exports = (io) => {
  io.use((socket, next) => {
    try {
      const token = socket.handshake.auth?.token || socket.handshake.query?.token;
      if (!token) return next(new Error('No token'));
      const decoded = jwt.verify(token, process.env.JWT_SECRET || 'SuperSecretJWT2024!');
      socket.user = decoded;
      next();
    } catch {
      next(new Error('Invalid token'));
    }
  });

  io.on('connection', (socket) => {
    const factoryId = socket.user?.factory_id;
    if (factoryId) {
      socket.join(`factory:${factoryId}`);
      logger.info(`Socket connected: user ${socket.user.id} factory ${factoryId}`);
    }

    socket.on('mark_alert_read', async (alertId) => {
      try {
        const { Alert } = require('../models');
        await Alert.update({ is_read: true, read_by: socket.user.id }, { where: { id: alertId } });
        socket.emit('alert_marked_read', alertId);
      } catch {}
    });

    socket.on('disconnect', () => {
      logger.info(`Socket disconnected: ${socket.id}`);
    });
  });

  // Periodic checks every 10 minutes
  setInterval(async () => {
    try {
      const { Factory } = require('../models');
      const factories = await Factory.findAll({ where: { is_active: true } });
      const { runAlertCheck } = require('../controllers/inventoryController');
      for (const f of factories) await runAlertCheck(f.id);
    } catch {}
  }, 10 * 60 * 1000);
};
