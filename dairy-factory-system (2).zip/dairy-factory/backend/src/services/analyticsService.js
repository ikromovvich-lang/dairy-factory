const axios = require('axios');
const { MilkCollection, SalesOrder, SaleOrderItem, ProductionBatch, AIPrediction, sequelize } = require('../models');
const { Op } = require('sequelize');

const AI_URL = process.env.AI_SERVICE_URL || 'http://localhost:8001';

async function getHistoricalMilkData(factoryId, days = 90) {
  const startDate = new Date(); startDate.setDate(startDate.getDate() - days);
  return MilkCollection.findAll({
    where: { factory_id: factoryId, collection_date: { [Op.gte]: startDate.toISOString().split('T')[0] } },
    attributes: ['collection_date', [sequelize.fn('SUM', sequelize.col('liters')), 'liters']],
    group: ['collection_date'], order: [['collection_date', 'ASC']], raw: true
  });
}

async function getHistoricalSalesData(factoryId, days = 90) {
  const startDate = new Date(); startDate.setDate(startDate.getDate() - days);
  return SaleOrderItem.findAll({
    attributes: [
      [sequelize.literal('"SalesOrder"."order_date"'), 'date'],
      'product_type',
      [sequelize.fn('SUM', sequelize.col('"SaleOrderItem"."quantity"')), 'quantity'],
      [sequelize.fn('SUM', sequelize.col('"SaleOrderItem"."total_price"')), 'revenue']
    ],
    include: [{
      model: SalesOrder, attributes: [],
      where: { factory_id: factoryId, status: { [Op.ne]: 'cancelled' },
        order_date: { [Op.gte]: startDate.toISOString().split('T')[0] } }
    }],
    group: [sequelize.literal('"SalesOrder"."order_date"'), '"SaleOrderItem"."product_type"'],
    order: [[sequelize.literal('"SalesOrder"."order_date"'), 'ASC']], raw: true
  });
}

async function runForecast(factoryId) {
  try {
    const [milkData, salesData] = await Promise.all([
      getHistoricalMilkData(factoryId),
      getHistoricalSalesData(factoryId)
    ]);

    if (milkData.length < 7) {
      return generateSimpleForecast(milkData, salesData);
    }

    const response = await axios.post(`${AI_URL}/predict`, { milk_data: milkData, sales_data: salesData, factory_id: factoryId }, { timeout: 30000 });
    const predictions = response.data;

    await AIPrediction.bulkCreate(
      predictions.forecasts.map(p => ({ factory_id: factoryId, ...p })),
      { ignoreDuplicates: true }
    );
    return predictions;
  } catch (err) {
    console.warn('AI service unavailable, using local forecast:', err.message);
    const [milkData, salesData] = await Promise.all([getHistoricalMilkData(factoryId), getHistoricalSalesData(factoryId)]);
    return generateSimpleForecast(milkData, salesData);
  }
}

function generateSimpleForecast(milkData, salesData) {
  const avgMilk = milkData.length
    ? milkData.reduce((s, d) => s + parseFloat(d.liters || 0), 0) / milkData.length
    : 5000;

  const weekForecast = Array.from({ length: 7 }, (_, i) => {
    const date = new Date(); date.setDate(date.getDate() + i + 1);
    const dayOfWeek = date.getDay();
    const factor = dayOfWeek === 0 ? 0.8 : dayOfWeek === 6 ? 0.9 : 1.0;
    return {
      date: date.toISOString().split('T')[0],
      predicted_milk: Math.round(avgMilk * factor * (0.95 + Math.random() * 0.1)),
      confidence: 75
    };
  });

  const productTypes = ['milk', 'yogurt', 'tvorog', 'smetana'];
  const salesForecast = productTypes.map(pt => {
    const ptData = salesData.filter(d => d.product_type === pt);
    const avgQty = ptData.length ? ptData.reduce((s, d) => s + parseFloat(d.quantity || 0), 0) / ptData.length : 100;
    return {
      product_type: pt,
      weekly_forecast: Math.round(avgQty * 7 * (0.9 + Math.random() * 0.2)),
      trend: avgQty > 80 ? 'up' : 'stable',
      confidence: 70
    };
  });

  return {
    milk_forecast: weekForecast,
    sales_forecast: salesForecast,
    recommendations: [
      { type: 'production', message: `Haftalik sut yig\'imi: ~${Math.round(avgMilk * 7)}L kutilmoqda`, priority: 'medium' },
      { type: 'inventory', message: 'Tvorog va Smetana zaxirasini ko\'paytiring', priority: 'high' }
    ],
    generated_at: new Date().toISOString(),
    model: 'local_fallback'
  };
}

module.exports = { runForecast, getHistoricalMilkData, getHistoricalSalesData };
