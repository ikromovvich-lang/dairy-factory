const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Farmer = sequelize.define('Farmer', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  name: { type: DataTypes.STRING(100), allowNull: false },
  phone: { type: DataTypes.STRING(20), allowNull: false },
  location: { type: DataTypes.STRING(200), allowNull: false },
  address: { type: DataTypes.TEXT },
  bankAccount: { type: DataTypes.STRING(50) },
  isActive: { type: DataTypes.BOOLEAN, defaultValue: true },
  totalDeliveries: { type: DataTypes.INTEGER, defaultValue: 0 },
  totalLiters: { type: DataTypes.DECIMAL(10, 2), defaultValue: 0 },
  totalPayment: { type: DataTypes.DECIMAL(12, 2), defaultValue: 0 },
  avgFatPercent: { type: DataTypes.DECIMAL(4, 2), defaultValue: 0 },
  notes: { type: DataTypes.TEXT }
}, { timestamps: true });

module.exports = Farmer;
