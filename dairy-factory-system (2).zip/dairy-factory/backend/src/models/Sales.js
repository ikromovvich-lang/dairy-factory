const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Customer = sequelize.define('Customer', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  name: { type: DataTypes.STRING(100), allowNull: false },
  type: { type: DataTypes.ENUM('shop', 'distributor', 'restaurant', 'individual'), defaultValue: 'shop' },
  phone: { type: DataTypes.STRING(20) },
  email: { type: DataTypes.STRING },
  address: { type: DataTypes.TEXT },
  taxId: { type: DataTypes.STRING(50) },
  creditLimit: { type: DataTypes.DECIMAL(12, 2), defaultValue: 0 },
  currentDebt: { type: DataTypes.DECIMAL(12, 2), defaultValue: 0 },
  isActive: { type: DataTypes.BOOLEAN, defaultValue: true },
  notes: { type: DataTypes.TEXT }
}, { timestamps: true });

const Sale = sequelize.define('Sale', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  invoiceNumber: { type: DataTypes.STRING(20), unique: true },
  customerId: { type: DataTypes.UUID, allowNull: false },
  saleDate: { type: DataTypes.DATEONLY, defaultValue: DataTypes.NOW },
  items: { type: DataTypes.JSONB, allowNull: false },
  subtotal: { type: DataTypes.DECIMAL(12, 2) },
  tax: { type: DataTypes.DECIMAL(10, 2), defaultValue: 0 },
  discount: { type: DataTypes.DECIMAL(10, 2), defaultValue: 0 },
  totalAmount: { type: DataTypes.DECIMAL(12, 2), allowNull: false },
  paymentMethod: { type: DataTypes.ENUM('cash', 'transfer', 'credit'), defaultValue: 'cash' },
  paymentStatus: { type: DataTypes.ENUM('pending', 'paid', 'overdue'), defaultValue: 'pending' },
  paidAt: { type: DataTypes.DATE },
  notes: { type: DataTypes.TEXT },
  soldBy: { type: DataTypes.UUID }
}, { timestamps: true });

module.exports = { Customer, Sale };
