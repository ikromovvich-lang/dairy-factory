const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const MilkDelivery = sequelize.define('MilkDelivery', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  farmerId: { type: DataTypes.UUID, allowNull: false },
  deliveryDate: { type: DataTypes.DATEONLY, allowNull: false, defaultValue: DataTypes.NOW },
  deliveryTime: { type: DataTypes.TIME, defaultValue: '08:00:00' },
  liters: { type: DataTypes.DECIMAL(8, 2), allowNull: false },
  fatPercent: { type: DataTypes.DECIMAL(4, 2), allowNull: false },
  proteinPercent: { type: DataTypes.DECIMAL(4, 2), defaultValue: 3.2 },
  temperature: { type: DataTypes.DECIMAL(4, 1) },
  qualityGrade: { type: DataTypes.ENUM('A', 'B', 'C', 'rejected'), allowNull: false },
  soilContent: { type: DataTypes.DECIMAL(5, 3), defaultValue: 0 },
  antibiotics: { type: DataTypes.BOOLEAN, defaultValue: false },
  pricePerLiter: { type: DataTypes.DECIMAL(8, 2), allowNull: false },
  totalPayment: { type: DataTypes.DECIMAL(10, 2), allowNull: false },
  isPaid: { type: DataTypes.BOOLEAN, defaultValue: false },
  paidAt: { type: DataTypes.DATE },
  notes: { type: DataTypes.TEXT },
  receivedBy: { type: DataTypes.UUID }
}, { timestamps: true });

module.exports = MilkDelivery;
