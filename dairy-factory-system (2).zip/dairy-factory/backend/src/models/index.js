const { sequelize } = require('../config/database');
const { DataTypes } = require('sequelize');

// User Model
const User = sequelize.define('User', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  name: { type: DataTypes.STRING(100), allowNull: false },
  email: { type: DataTypes.STRING(255), allowNull: false, unique: true },
  phone: DataTypes.STRING(20),
  password_hash: { type: DataTypes.STRING(255), allowNull: false },
  role: { type: DataTypes.ENUM('admin', 'manager', 'worker'), defaultValue: 'worker' },
  factory_id: DataTypes.UUID,
  is_active: { type: DataTypes.BOOLEAN, defaultValue: true },
  last_login: DataTypes.DATE,
  avatar_url: DataTypes.STRING(500),
  refresh_token_hash: DataTypes.STRING(255)
}, { tableName: 'users', underscored: true });

// Factory Model
const Factory = sequelize.define('Factory', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  name: { type: DataTypes.STRING(200), allowNull: false },
  location: DataTypes.STRING(500),
  license_number: DataTypes.STRING(100),
  capacity_liters_per_day: { type: DataTypes.INTEGER, defaultValue: 10000 },
  is_active: { type: DataTypes.BOOLEAN, defaultValue: true },
  settings: { type: DataTypes.JSONB, defaultValue: {} }
}, { tableName: 'factories', underscored: true });

// Farmer Model
const Farmer = sequelize.define('Farmer', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  factory_id: { type: DataTypes.UUID, allowNull: false },
  name: { type: DataTypes.STRING(150), allowNull: false },
  phone: { type: DataTypes.STRING(20), allowNull: false },
  location: DataTypes.STRING(300),
  bank_account: DataTypes.STRING(50),
  price_per_liter: { type: DataTypes.DECIMAL(10,2), defaultValue: 3500 },
  is_active: { type: DataTypes.BOOLEAN, defaultValue: true },
  total_delivered: { type: DataTypes.DECIMAL(12,2), defaultValue: 0 },
  total_paid: { type: DataTypes.DECIMAL(14,2), defaultValue: 0 },
  notes: DataTypes.TEXT
}, { tableName: 'farmers', underscored: true });

// MilkCollection Model
const MilkCollection = sequelize.define('MilkCollection', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  factory_id: { type: DataTypes.UUID, allowNull: false },
  farmer_id: { type: DataTypes.UUID, allowNull: false },
  collection_date: { type: DataTypes.DATEONLY, defaultValue: DataTypes.NOW },
  liters: { type: DataTypes.DECIMAL(10,2), allowNull: false },
  fat_percentage: { type: DataTypes.DECIMAL(4,2), allowNull: false },
  protein_percentage: { type: DataTypes.DECIMAL(4,2), defaultValue: 3.2 },
  temperature: DataTypes.DECIMAL(4,1),
  quality_grade: { type: DataTypes.ENUM('premium', 'first', 'second', 'rejected'), allowNull: false },
  price_per_liter: { type: DataTypes.DECIMAL(10,2), allowNull: false },
  total_payment: { type: DataTypes.DECIMAL(12,2) },
  is_paid: { type: DataTypes.BOOLEAN, defaultValue: false },
  paid_at: DataTypes.DATE,
  notes: DataTypes.TEXT,
  recorded_by: DataTypes.UUID
}, { tableName: 'milk_collections', underscored: true });

// ProductRecipe Model
const ProductRecipe = sequelize.define('ProductRecipe', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  factory_id: { type: DataTypes.UUID, allowNull: false },
  product_type: { type: DataTypes.ENUM('milk', 'yogurt', 'tvorog', 'smetana'), allowNull: false },
  product_name: { type: DataTypes.STRING(200), allowNull: false },
  milk_per_unit: { type: DataTypes.DECIMAL(8,3), allowNull: false },
  unit: { type: DataTypes.STRING(20), defaultValue: 'kg' },
  yield_percentage: { type: DataTypes.DECIMAL(5,2), defaultValue: 85 },
  min_fat_required: { type: DataTypes.DECIMAL(4,2), defaultValue: 3.2 },
  processing_hours: { type: DataTypes.INTEGER, defaultValue: 4 },
  shelf_life_days: { type: DataTypes.INTEGER, allowNull: false },
  price_per_unit: { type: DataTypes.DECIMAL(10,2), allowNull: false },
  description: DataTypes.TEXT,
  is_active: { type: DataTypes.BOOLEAN, defaultValue: true }
}, { tableName: 'product_recipes', underscored: true });

// ProductionBatch Model
const ProductionBatch = sequelize.define('ProductionBatch', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  factory_id: { type: DataTypes.UUID, allowNull: false },
  batch_id: { type: DataTypes.STRING(20), unique: true, allowNull: false },
  recipe_id: { type: DataTypes.UUID, allowNull: false },
  product_type: { type: DataTypes.ENUM('milk', 'yogurt', 'tvorog', 'smetana'), allowNull: false },
  product_name: { type: DataTypes.STRING(200), allowNull: false },
  status: { type: DataTypes.ENUM('planned', 'in_progress', 'completed', 'failed', 'recalled'), defaultValue: 'planned' },
  production_date: { type: DataTypes.DATEONLY, defaultValue: DataTypes.NOW },
  expiration_date: { type: DataTypes.DATEONLY, allowNull: false },
  milk_used_liters: { type: DataTypes.DECIMAL(10,2), allowNull: false },
  quantity_produced: DataTypes.DECIMAL(10,2),
  quantity_planned: { type: DataTypes.DECIMAL(10,2), allowNull: false },
  yield_actual: DataTypes.DECIMAL(5,2),
  fat_percentage: DataTypes.DECIMAL(4,2),
  quality_score: DataTypes.INTEGER,
  qr_code_url: DataTypes.STRING(500),
  qr_code_data: DataTypes.TEXT,
  notes: DataTypes.TEXT,
  started_by: DataTypes.UUID,
  completed_by: DataTypes.UUID,
  started_at: DataTypes.DATE,
  completed_at: DataTypes.DATE
}, { tableName: 'production_batches', underscored: true });

// Inventory Model
const Inventory = sequelize.define('Inventory', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  factory_id: { type: DataTypes.UUID, allowNull: false },
  product_type: { type: DataTypes.ENUM('milk', 'yogurt', 'tvorog', 'smetana'), allowNull: false },
  product_name: { type: DataTypes.STRING(200), allowNull: false },
  batch_id: DataTypes.UUID,
  quantity: { type: DataTypes.DECIMAL(12,2), defaultValue: 0 },
  unit: { type: DataTypes.STRING(20), defaultValue: 'kg' },
  min_stock_alert: { type: DataTypes.DECIMAL(10,2), defaultValue: 50 },
  expiration_date: DataTypes.DATEONLY,
  location: { type: DataTypes.STRING(100), defaultValue: 'Main Warehouse' },
  price_per_unit: DataTypes.DECIMAL(10,2)
}, { tableName: 'inventory', underscored: true });

// Customer Model
const Customer = sequelize.define('Customer', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  factory_id: { type: DataTypes.UUID, allowNull: false },
  name: { type: DataTypes.STRING(200), allowNull: false },
  type: { type: DataTypes.ENUM('shop', 'distributor', 'restaurant', 'individual'), defaultValue: 'shop' },
  phone: DataTypes.STRING(20),
  email: DataTypes.STRING(255),
  address: DataTypes.STRING(500),
  tin_number: DataTypes.STRING(50),
  credit_limit: { type: DataTypes.DECIMAL(14,2), defaultValue: 0 },
  current_balance: { type: DataTypes.DECIMAL(14,2), defaultValue: 0 },
  discount_percentage: { type: DataTypes.DECIMAL(5,2), defaultValue: 0 },
  is_active: { type: DataTypes.BOOLEAN, defaultValue: true },
  total_purchases: { type: DataTypes.DECIMAL(16,2), defaultValue: 0 },
  notes: DataTypes.TEXT
}, { tableName: 'customers', underscored: true });

// SalesOrder Model
const SalesOrder = sequelize.define('SalesOrder', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  factory_id: { type: DataTypes.UUID, allowNull: false },
  order_number: { type: DataTypes.STRING(20), unique: true, allowNull: false },
  customer_id: { type: DataTypes.UUID, allowNull: false },
  status: { type: DataTypes.ENUM('pending', 'confirmed', 'delivered', 'cancelled'), defaultValue: 'pending' },
  order_date: { type: DataTypes.DATEONLY, defaultValue: DataTypes.NOW },
  delivery_date: DataTypes.DATEONLY,
  subtotal: { type: DataTypes.DECIMAL(14,2), defaultValue: 0 },
  discount_amount: { type: DataTypes.DECIMAL(12,2), defaultValue: 0 },
  tax_amount: { type: DataTypes.DECIMAL(12,2), defaultValue: 0 },
  total_amount: { type: DataTypes.DECIMAL(14,2), defaultValue: 0 },
  paid_amount: { type: DataTypes.DECIMAL(14,2), defaultValue: 0 },
  notes: DataTypes.TEXT,
  created_by: DataTypes.UUID
}, { tableName: 'sales_orders', underscored: true });

// SaleOrderItem Model
const SaleOrderItem = sequelize.define('SaleOrderItem', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  order_id: { type: DataTypes.UUID, allowNull: false },
  product_type: { type: DataTypes.ENUM('milk', 'yogurt', 'tvorog', 'smetana'), allowNull: false },
  product_name: { type: DataTypes.STRING(200), allowNull: false },
  batch_id: DataTypes.UUID,
  quantity: { type: DataTypes.DECIMAL(10,2), allowNull: false },
  unit: { type: DataTypes.STRING(20), defaultValue: 'kg' },
  unit_price: { type: DataTypes.DECIMAL(10,2), allowNull: false },
  discount_percentage: { type: DataTypes.DECIMAL(5,2), defaultValue: 0 },
  total_price: DataTypes.DECIMAL(12,2)
}, { tableName: 'sale_order_items', underscored: true });

// Alert Model
const Alert = sequelize.define('Alert', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  factory_id: { type: DataTypes.UUID, allowNull: false },
  type: { type: DataTypes.ENUM('low_stock', 'expiring_soon', 'out_of_stock', 'quality_issue', 'low_milk', 'system'), allowNull: false },
  severity: { type: DataTypes.ENUM('info', 'warning', 'critical'), defaultValue: 'warning' },
  title: { type: DataTypes.STRING(300), allowNull: false },
  message: { type: DataTypes.TEXT, allowNull: false },
  related_id: DataTypes.UUID,
  related_type: DataTypes.STRING(50),
  is_read: { type: DataTypes.BOOLEAN, defaultValue: false },
  is_resolved: { type: DataTypes.BOOLEAN, defaultValue: false },
  read_by: DataTypes.UUID,
  resolved_by: DataTypes.UUID,
  resolved_at: DataTypes.DATE
}, { tableName: 'alerts', underscored: true });

// AIPrediction Model
const AIPrediction = sequelize.define('AIPrediction', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  factory_id: { type: DataTypes.UUID, allowNull: false },
  prediction_type: { type: DataTypes.STRING(50), allowNull: false },
  product_type: DataTypes.ENUM('milk', 'yogurt', 'tvorog', 'smetana'),
  prediction_date: { type: DataTypes.DATEONLY, allowNull: false },
  predicted_value: { type: DataTypes.DECIMAL(14,2), allowNull: false },
  confidence_score: DataTypes.DECIMAL(5,2),
  actual_value: DataTypes.DECIMAL(14,2),
  model_version: DataTypes.STRING(20),
  metadata: { type: DataTypes.JSONB, defaultValue: {} }
}, { tableName: 'ai_predictions', underscored: true });

// Associations
Factory.hasMany(User, { foreignKey: 'factory_id' });
User.belongsTo(Factory, { foreignKey: 'factory_id' });
Factory.hasMany(Farmer, { foreignKey: 'factory_id' });
Farmer.belongsTo(Factory, { foreignKey: 'factory_id' });
Factory.hasMany(MilkCollection, { foreignKey: 'factory_id' });
MilkCollection.belongsTo(Factory, { foreignKey: 'factory_id' });
Farmer.hasMany(MilkCollection, { foreignKey: 'farmer_id' });
MilkCollection.belongsTo(Farmer, { foreignKey: 'farmer_id' });
Factory.hasMany(ProductRecipe, { foreignKey: 'factory_id' });
Factory.hasMany(ProductionBatch, { foreignKey: 'factory_id' });
ProductRecipe.hasMany(ProductionBatch, { foreignKey: 'recipe_id' });
ProductionBatch.belongsTo(ProductRecipe, { foreignKey: 'recipe_id' });
Factory.hasMany(Inventory, { foreignKey: 'factory_id' });
ProductionBatch.hasOne(Inventory, { foreignKey: 'batch_id' });
Factory.hasMany(Customer, { foreignKey: 'factory_id' });
Factory.hasMany(SalesOrder, { foreignKey: 'factory_id' });
Customer.hasMany(SalesOrder, { foreignKey: 'customer_id' });
SalesOrder.belongsTo(Customer, { foreignKey: 'customer_id' });
SalesOrder.hasMany(SaleOrderItem, { foreignKey: 'order_id', as: 'items' });
SaleOrderItem.belongsTo(SalesOrder, { foreignKey: 'order_id' });
Factory.hasMany(Alert, { foreignKey: 'factory_id' });
Factory.hasMany(AIPrediction, { foreignKey: 'factory_id' });

module.exports = {
  sequelize, User, Factory, Farmer, MilkCollection, ProductRecipe,
  ProductionBatch, Inventory, Customer, SalesOrder, SaleOrderItem, Alert, AIPrediction
};
