const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Inventory = sequelize.define('Inventory', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  productType: { type: DataTypes.ENUM('milk', 'yogurt', 'tvorog', 'smetana'), unique: true },
  currentStock: { type: DataTypes.DECIMAL(10, 2), defaultValue: 0 },
  unit: { type: DataTypes.STRING(20), defaultValue: 'liters' },
  lowStockThreshold: { type: DataTypes.DECIMAL(8, 2), defaultValue: 50 },
  maxCapacity: { type: DataTypes.DECIMAL(10, 2), defaultValue: 5000 },
  lastUpdated: { type: DataTypes.DATE, defaultValue: DataTypes.NOW },
  reservedStock: { type: DataTypes.DECIMAL(8, 2), defaultValue: 0 }
}, { timestamps: true });

const Notification = sequelize.define('Notification', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  type: { type: DataTypes.ENUM('low_stock', 'expiring_product', 'out_of_stock', 'quality_alert', 'payment_due', 'system'), allowNull: false },
  title: { type: DataTypes.STRING(200), allowNull: false },
  message: { type: DataTypes.TEXT, allowNull: false },
  severity: { type: DataTypes.ENUM('info', 'warning', 'critical'), defaultValue: 'info' },
  isRead: { type: DataTypes.BOOLEAN, defaultValue: false },
  targetRole: { type: DataTypes.STRING(50), defaultValue: 'all' },
  metadata: { type: DataTypes.JSONB }
}, { timestamps: true });

module.exports = { Inventory, Notification };
