const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const ProductBatch = sequelize.define('ProductBatch', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  batchId: { type: DataTypes.STRING(20), unique: true, allowNull: false },
  productType: { type: DataTypes.ENUM('milk', 'yogurt', 'tvorog', 'smetana'), allowNull: false },
  productName: { type: DataTypes.STRING(100) },
  productionDate: { type: DataTypes.DATEONLY, allowNull: false },
  expirationDate: { type: DataTypes.DATEONLY, allowNull: false },
  milkUsed: { type: DataTypes.DECIMAL(8, 2), allowNull: false },
  quantityProduced: { type: DataTypes.DECIMAL(8, 2), allowNull: false },
  unit: { type: DataTypes.ENUM('liters', 'kg', 'pieces'), defaultValue: 'liters' },
  yieldPercent: { type: DataTypes.DECIMAL(5, 2) },
  fatContent: { type: DataTypes.DECIMAL(4, 2) },
  status: { type: DataTypes.ENUM('in_production', 'completed', 'quality_check', 'approved', 'rejected'), defaultValue: 'in_production' },
  qrCode: { type: DataTypes.TEXT },
  qrCodeData: { type: DataTypes.JSONB },
  costPerUnit: { type: DataTypes.DECIMAL(8, 2) },
  sellingPrice: { type: DataTypes.DECIMAL(8, 2) },
  notes: { type: DataTypes.TEXT },
  producedBy: { type: DataTypes.UUID },
  approvedBy: { type: DataTypes.UUID },
  currentStock: { type: DataTypes.DECIMAL(8, 2), defaultValue: 0 }
}, { timestamps: true });

module.exports = ProductBatch;
