const { Inventory, ProductionBatch, sequelize } = require('../models');
const { Op } = require('sequelize');
const { createAlert } = require('../services/alertService');

exports.getAll = async (req, res) => {
  try {
    const { product_type, low_stock } = req.query;
    const where = { factory_id: req.factoryId };
    if (product_type) where.product_type = product_type;
    if (low_stock === 'true') where[Op.col('quantity')] = { [Op.lte]: sequelize.col('min_stock_alert') };

    const inventory = await Inventory.findAll({
      where,
      include: [{ model: ProductionBatch, attributes: ['batch_id', 'production_date', 'expiration_date', 'quality_score'] }],
      order: [['expiration_date', 'ASC']]
    });

    // Annotate with alert flags
    const now = new Date();
    const annotated = inventory.map(item => {
      const daysToExpiry = item.expiration_date
        ? Math.floor((new Date(item.expiration_date) - now) / 86400000) : 999;
      return {
        ...item.toJSON(),
        is_low_stock: parseFloat(item.quantity) <= parseFloat(item.min_stock_alert),
        is_out_of_stock: parseFloat(item.quantity) === 0,
        days_to_expiry: daysToExpiry,
        expiry_status: daysToExpiry <= 1 ? 'critical' : daysToExpiry <= 3 ? 'warning' : 'ok'
      };
    });

    res.json(annotated);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getSummary = async (req, res) => {
  try {
    const summary = await Inventory.findAll({
      where: { factory_id: req.factoryId },
      attributes: [
        'product_type',
        [sequelize.fn('SUM', sequelize.col('quantity')), 'total_quantity'],
        [sequelize.fn('SUM', sequelize.literal('quantity * price_per_unit')), 'total_value'],
        [sequelize.fn('COUNT', sequelize.col('id')), 'batches']
      ],
      group: ['product_type']
    });

    const lowStock = await Inventory.count({
      where: { factory_id: req.factoryId, quantity: { [Op.lte]: sequelize.col('min_stock_alert') } }
    });

    const expiringSoon = await Inventory.count({
      where: {
        factory_id: req.factoryId,
        expiration_date: { [Op.between]: [new Date(), new Date(Date.now() + 3 * 86400000)] }
      }
    });

    res.json({ by_product: summary, low_stock_count: lowStock, expiring_soon_count: expiringSoon });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.adjust = async (req, res) => {
  try {
    const { id } = req.params;
    const { quantity, reason } = req.body;
    const item = await Inventory.findOne({ where: { id, factory_id: req.factoryId } });
    if (!item) return res.status(404).json({ error: 'Inventory item not found' });
    
    const old_qty = item.quantity;
    await item.update({ quantity });
    
    if (parseFloat(quantity) <= parseFloat(item.min_stock_alert)) {
      await createAlert(req.factoryId, 'low_stock', parseFloat(quantity) === 0 ? 'critical' : 'warning',
        parseFloat(quantity) === 0 ? 'Mahsulot tugadi!' : 'Kam zaxira!',
        `${item.product_name}: ${quantity} ${item.unit} qoldi`, item.id, 'inventory');
      if (global.io) global.io.to(`factory:${req.factoryId}`).emit('low_stock_alert', { product: item.product_name, quantity });
    }
    
    res.json({ ...item.toJSON(), old_quantity: old_qty });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.runAlertCheck = async (factoryId) => {
  const items = await Inventory.findAll({ where: { factory_id: factoryId } });
  const now = new Date();
  for (const item of items) {
    if (parseFloat(item.quantity) === 0) {
      await createAlert(factoryId, 'out_of_stock', 'critical', `${item.product_name} tugadi!`,
        `Omborda ${item.product_name} qolmadi. Zudlik bilan ishlab chiqarish kerak.`, item.id, 'inventory');
    } else if (parseFloat(item.quantity) <= parseFloat(item.min_stock_alert)) {
      await createAlert(factoryId, 'low_stock', 'warning', `Kam zaxira: ${item.product_name}`,
        `Faqat ${item.quantity} ${item.unit} qoldi.`, item.id, 'inventory');
    }
    if (item.expiration_date) {
      const days = Math.floor((new Date(item.expiration_date) - now) / 86400000);
      if (days <= 2 && days >= 0) {
        await createAlert(factoryId, 'expiring_soon', days === 0 ? 'critical' : 'warning',
          `Muddati tugayapti: ${item.product_name}`,
          `${item.product_name} ${days === 0 ? 'bugun' : days + ' kunda'} muddati tugaydi!`, item.id, 'inventory');
      }
    }
  }
};
