const { SalesOrder, SaleOrderItem, Customer, Inventory, sequelize } = require('../models');
const { Op } = require('sequelize');

const generateOrderNumber = () => {
  const d = new Date();
  const date = `${d.getFullYear().toString().slice(2)}${(d.getMonth()+1).toString().padStart(2,'0')}${d.getDate().toString().padStart(2,'0')}`;
  const rand = Math.floor(Math.random() * 9999).toString().padStart(4, '0');
  return `ORD${date}${rand}`;
};

exports.createOrder = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const { customer_id, items, delivery_date, notes } = req.body;

    const customer = await Customer.findOne({ where: { id: customer_id, factory_id: req.factoryId } });
    if (!customer) return res.status(404).json({ error: 'Customer not found' });

    let subtotal = 0;
    const orderItems = [];

    for (const item of items) {
      // Check inventory
      const inv = await Inventory.findOne({
        where: { factory_id: req.factoryId, product_type: item.product_type, quantity: { [Op.gte]: item.quantity } },
        order: [['expiration_date', 'ASC']], transaction: t
      });
      if (!inv) return res.status(400).json({ error: `Insufficient stock for ${item.product_name}` });

      const discount = item.discount_percentage || customer.discount_percentage || 0;
      const line_total = item.quantity * item.unit_price * (1 - discount / 100);
      subtotal += line_total;

      orderItems.push({
        product_type: item.product_type,
        product_name: item.product_name || inv.product_name,
        batch_id: inv.batch_id,
        quantity: item.quantity,
        unit: inv.unit,
        unit_price: item.unit_price,
        discount_percentage: discount,
        total_price: line_total
      });

      await inv.update({ quantity: parseFloat(inv.quantity) - parseFloat(item.quantity) }, { transaction: t });
    }

    const discount_amount = subtotal * (customer.discount_percentage / 100);
    const tax_amount = (subtotal - discount_amount) * 0.12;
    const total_amount = subtotal - discount_amount + tax_amount;

    const order = await SalesOrder.create({
      factory_id: req.factoryId,
      order_number: generateOrderNumber(),
      customer_id, delivery_date, notes,
      status: 'confirmed',
      subtotal, discount_amount, tax_amount, total_amount,
      created_by: req.user.id
    }, { transaction: t });

    for (const item of orderItems) {
      await SaleOrderItem.create({ order_id: order.id, ...item }, { transaction: t });
    }

    await customer.update({
      total_purchases: parseFloat(customer.total_purchases) + total_amount,
      current_balance: parseFloat(customer.current_balance) + total_amount
    }, { transaction: t });

    await t.commit();

    if (global.io) {
      global.io.to(`factory:${req.factoryId}`).emit('sale_created', { order_number: order.order_number, total: total_amount, customer: customer.name });
    }

    const full = await SalesOrder.findByPk(order.id, { include: [{ model: SaleOrderItem, as: 'items' }, { model: Customer }] });
    res.status(201).json(full);
  } catch (err) {
    await t.rollback();
    res.status(500).json({ error: err.message });
  }
};

exports.getOrders = async (req, res) => {
  try {
    const { status, customer_id, page = 1, limit = 20, date_from, date_to } = req.query;
    const where = { factory_id: req.factoryId };
    if (status) where.status = status;
    if (customer_id) where.customer_id = customer_id;
    if (date_from && date_to) where.order_date = { [Op.between]: [date_from, date_to] };

    const { count, rows } = await SalesOrder.findAndCountAll({
      where,
      include: [
        { model: Customer, attributes: ['name', 'type', 'phone'] },
        { model: SaleOrderItem, as: 'items' }
      ],
      order: [['created_at', 'DESC']],
      limit: parseInt(limit), offset: (parseInt(page)-1) * parseInt(limit)
    });

    res.json({ total: count, page: parseInt(page), data: rows });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getDailyRevenue = async (req, res) => {
  try {
    const { days = 30 } = req.query;
    const start = new Date(); start.setDate(start.getDate() - parseInt(days));

    const revenue = await SalesOrder.findAll({
      where: { factory_id: req.factoryId, status: { [Op.in]: ['confirmed', 'delivered'] },
        order_date: { [Op.gte]: start.toISOString().split('T')[0] } },
      attributes: [
        'order_date',
        [sequelize.fn('SUM', sequelize.col('total_amount')), 'revenue'],
        [sequelize.fn('COUNT', sequelize.col('id')), 'orders']
      ],
      group: ['order_date'], order: [['order_date', 'ASC']]
    });

    const today = new Date().toISOString().split('T')[0];
    const todayRevenue = await SalesOrder.sum('total_amount', {
      where: { factory_id: req.factoryId, order_date: today, status: { [Op.in]: ['confirmed', 'delivered'] } }
    });

    res.json({ daily: revenue, today_revenue: todayRevenue || 0 });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getRevenueByProduct = async (req, res) => {
  try {
    const { days = 30 } = req.query;
    const start = new Date(); start.setDate(start.getDate() - parseInt(days));
    
    const result = await SaleOrderItem.findAll({
      include: [{ model: SalesOrder, where: { factory_id: req.factoryId,
        order_date: { [Op.gte]: start.toISOString().split('T')[0] },
        status: { [Op.in]: ['confirmed', 'delivered'] }
      }, attributes: [] }],
      attributes: [
        'product_type',
        [sequelize.fn('SUM', sequelize.col('total_price')), 'revenue'],
        [sequelize.fn('SUM', sequelize.col('quantity')), 'qty_sold']
      ],
      group: ['product_type']
    });

    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
