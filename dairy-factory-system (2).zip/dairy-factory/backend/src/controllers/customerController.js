const { Customer, SalesOrder, SaleOrderItem, sequelize } = require('../models');
const { Op } = require('sequelize');

exports.getAll = async (req, res) => {
  try {
    const customers = await Customer.findAll({ where: { factory_id: req.factoryId, is_active: true }, order: [['name','ASC']] });
    res.json(customers);
  } catch (err) { res.status(500).json({ error: err.message }); }
};

exports.create = async (req, res) => {
  try {
    const customer = await Customer.create({ ...req.body, factory_id: req.factoryId });
    res.status(201).json(customer);
  } catch (err) { res.status(500).json({ error: err.message }); }
};

exports.update = async (req, res) => {
  try {
    const customer = await Customer.findOne({ where: { id: req.params.id, factory_id: req.factoryId } });
    if (!customer) return res.status(404).json({ error: 'Not found' });
    await customer.update(req.body);
    res.json(customer);
  } catch (err) { res.status(500).json({ error: err.message }); }
};
