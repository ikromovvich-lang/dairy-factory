const { MilkCollection, Farmer, sequelize } = require('../models');
const { Op } = require('sequelize');
const { createAlert } = require('../services/alertService');

// Price multipliers by quality grade
const QUALITY_MULTIPLIERS = { premium: 1.2, first: 1.0, second: 0.85, rejected: 0 };

exports.create = async (req, res) => {
  try {
    const { farmer_id, liters, fat_percentage, protein_percentage, temperature, quality_grade, notes } = req.body;
    
    const farmer = await Farmer.findOne({ where: { id: farmer_id, factory_id: req.factoryId } });
    if (!farmer) return res.status(404).json({ error: 'Farmer not found' });
    if (quality_grade === 'rejected') {
      await createAlert(req.factoryId, 'quality_issue', 'critical', 'Milk Rejected', 
        `${farmer.name}dan kelgan sut rad etildi. ${liters}L sut qabul qilinmadi.`, farmer_id, 'farmer');
      return res.status(200).json({ message: 'Milk rejected and recorded', quality_grade });
    }

    const price_per_liter = parseFloat(farmer.price_per_liter) * QUALITY_MULTIPLIERS[quality_grade];
    const total_payment = parseFloat(liters) * price_per_liter;

    const collection = await MilkCollection.create({
      factory_id: req.factoryId, farmer_id, liters, fat_percentage, 
      protein_percentage, temperature, quality_grade,
      price_per_liter, total_payment, recorded_by: req.user.id, notes
    });

    await farmer.update({ total_delivered: parseFloat(farmer.total_delivered) + parseFloat(liters) });

    // Check total daily milk
    const todayTotal = await MilkCollection.sum('liters', {
      where: { factory_id: req.factoryId, collection_date: new Date().toISOString().split('T')[0] }
    });

    if (todayTotal < 2000) {
      await createAlert(req.factoryId, 'low_milk', 'warning', 'Kam sut yig\'ildi',
        `Bugungi sut yig\'imi: ${todayTotal}L - kutilgan miqdordan kam.`, null, null);
    }

    // Emit socket event
    if (global.io) {
      global.io.to(`factory:${req.factoryId}`).emit('milk_collected', { liters, farmer: farmer.name, total_today: todayTotal });
    }

    res.status(201).json({ ...collection.toJSON(), total_payment });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getAll = async (req, res) => {
  try {
    const { date, farmer_id, page = 1, limit = 20 } = req.query;
    const where = { factory_id: req.factoryId };
    if (date) where.collection_date = date;
    if (farmer_id) where.farmer_id = farmer_id;
    
    const { count, rows } = await MilkCollection.findAndCountAll({
      where, include: [{ model: Farmer, attributes: ['name', 'phone', 'location'] }],
      order: [['created_at', 'DESC']],
      limit: parseInt(limit), offset: (parseInt(page) - 1) * parseInt(limit)
    });
    
    res.json({ total: count, page: parseInt(page), data: rows });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getDailyReport = async (req, res) => {
  try {
    const date = req.query.date || new Date().toISOString().split('T')[0];
    
    const collections = await MilkCollection.findAll({
      where: { factory_id: req.factoryId, collection_date: date },
      include: [{ model: Farmer, attributes: ['name', 'phone', 'location'] }],
      order: [['created_at', 'ASC']]
    });

    const summary = collections.reduce((acc, c) => {
      acc.total_liters += parseFloat(c.liters);
      acc.total_payment += parseFloat(c.total_payment);
      acc.avg_fat = (acc.avg_fat * acc.count + parseFloat(c.fat_percentage)) / (acc.count + 1);
      acc.count++;
      acc.by_grade[c.quality_grade] = (acc.by_grade[c.quality_grade] || 0) + parseFloat(c.liters);
      return acc;
    }, { total_liters: 0, total_payment: 0, avg_fat: 0, count: 0, by_grade: {} });

    res.json({ date, summary, collections });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getStats = async (req, res) => {
  try {
    const { days = 30 } = req.query;
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - parseInt(days));

    const stats = await MilkCollection.findAll({
      where: { factory_id: req.factoryId, collection_date: { [Op.gte]: startDate.toISOString().split('T')[0] } },
      attributes: [
        'collection_date',
        [sequelize.fn('SUM', sequelize.col('liters')), 'total_liters'],
        [sequelize.fn('AVG', sequelize.col('fat_percentage')), 'avg_fat'],
        [sequelize.fn('SUM', sequelize.col('total_payment')), 'total_payment'],
        [sequelize.fn('COUNT', sequelize.col('id')), 'deliveries']
      ],
      group: ['collection_date'],
      order: [['collection_date', 'ASC']]
    });

    res.json(stats);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.markPaid = async (req, res) => {
  try {
    const { farmer_id, date_from, date_to } = req.body;
    const [updated] = await MilkCollection.update(
      { is_paid: true, paid_at: new Date() },
      { where: { factory_id: req.factoryId, farmer_id, is_paid: false,
          collection_date: { [Op.between]: [date_from, date_to] } } }
    );
    const totalPaid = await MilkCollection.sum('total_payment', {
      where: { factory_id: req.factoryId, farmer_id, collection_date: { [Op.between]: [date_from, date_to] } }
    });
    const farmer = await Farmer.findByPk(farmer_id);
    await farmer.update({ total_paid: parseFloat(farmer.total_paid) + (totalPaid || 0) });
    res.json({ updated, total_paid: totalPaid });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
