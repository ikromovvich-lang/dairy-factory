const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { User, Factory } = require('../models');
const logger = require('../utils/logger');

const JWT_SECRET = process.env.JWT_SECRET || 'SuperSecretJWT2024!';
const JWT_EXPIRES = '24h';

const generateToken = (user) => jwt.sign(
  { id: user.id, role: user.role, factory_id: user.factory_id },
  JWT_SECRET,
  { expiresIn: JWT_EXPIRES }
);

exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email and password required' });
    
    const user = await User.findOne({ where: { email: email.toLowerCase(), is_active: true } });
    if (!user) return res.status(401).json({ error: 'Invalid credentials' });
    
    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) return res.status(401).json({ error: 'Invalid credentials' });
    
    await user.update({ last_login: new Date() });
    const token = generateToken(user);
    
    res.json({
      token,
      user: {
        id: user.id, name: user.name, email: user.email,
        role: user.role, factory_id: user.factory_id, phone: user.phone
      }
    });
  } catch (err) {
    logger.error('Login error:', err);
    res.status(500).json({ error: 'Login failed' });
  }
};

exports.me = async (req, res) => {
  const factory = await Factory.findByPk(req.user.factory_id);
  res.json({ ...req.user.toJSON(), factory });
};

exports.register = async (req, res) => {
  try {
    const { name, email, password, role, phone } = req.body;
    const exists = await User.findOne({ where: { email: email.toLowerCase() } });
    if (exists) return res.status(409).json({ error: 'Email already registered' });
    const hash = await bcrypt.hash(password, 12);
    const user = await User.create({
      name, email: email.toLowerCase(), password_hash: hash,
      role: role || 'worker', phone, factory_id: req.user.factory_id
    });
    res.status(201).json({ id: user.id, name: user.name, email: user.email, role: user.role });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.changePassword = async (req, res) => {
  try {
    const { current_password, new_password } = req.body;
    const user = await User.findByPk(req.user.id);
    const valid = await bcrypt.compare(current_password, user.password_hash);
    if (!valid) return res.status(400).json({ error: 'Current password incorrect' });
    const hash = await bcrypt.hash(new_password, 12);
    await user.update({ password_hash: hash });
    res.json({ message: 'Password changed successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
