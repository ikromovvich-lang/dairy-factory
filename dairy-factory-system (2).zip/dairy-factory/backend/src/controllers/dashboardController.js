const { MilkCollection, ProductionBatch, Inventory, SalesOrder, Alert, Customer, Farmer, sequelize } = require('../models');
const { Op } = require('sequelize');

exports.getOverview = async (req, res) => {
  try {
    const today = new Date().toISOString().split('T')[0];
    const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
    const monthStart = new Date(); monthStart.setDate(1);
    const monthStartStr = monthStart.toISOString().split('T')[0];

    const [
      todayMilk, yesterdayMilk,
      todayRevenue, monthRevenue,
      activeBatches,
      totalInventoryValue,
      unreadAlerts,
      totalFarmers,
      totalCustomers,
      expiringItems
    ] = await Promise.all([
      MilkCollection.sum('liters', { where: { factory_id: req.factoryId, collection_date: today } }),
      MilkCollection.sum('liters', { where: { factory_id: req.factoryId, collection_date: yesterday } }),
      SalesOrder.sum('total_amount', { where: { factory_id: req.factoryId, order_date: today, status: { [Op.in]: ['confirmed', 'delivered'] } } }),
      SalesOrder.sum('total_amount', { where: { factory_id: req.factoryId, order_date: { [Op.gte]: monthStartStr }, status: { [Op.in]: ['confirmed', 'delivered'] } } }),
      ProductionBatch.count({ where: { factory_id: req.factoryId, status: 'in_progress' } }),
      Inventory.findAll({ where: { factory_id: req.factoryId }, attributes: [[sequelize.fn('SUM', sequelize.literal('quantity * price_per_unit')), 'value']] }),
      Alert.count({ where: { factory_id: req.factoryId, is_read: false } }),
      Farmer.count({ where: { factory_id: req.factoryId, is_active: true } }),
      Customer.count({ where: { factory_id: req.factoryId, is_active: true } }),
      Inventory.count({ where: { factory_id: req.factoryId, expiration_date: { [Op.lte]: new Date(Date.now() + 3 * 86400000) }, quantity: { [Op.gt]: 0 } } })
    ]);

    const milkChange = yesterdayMilk > 0 ? ((todayMilk - yesterdayMilk) / yesterdayMilk * 100).toFixed(1) : 0;

    res.json({
      today_milk_liters: todayMilk || 0,
      milk_change_pct: parseFloat(milkChange),
      today_revenue: todayRevenue || 0,
      month_revenue: monthRevenue || 0,
      active_batches: activeBatches,
      inventory_value: totalInventoryValue[0]?.dataValues?.value || 0,
      unread_alerts: unreadAlerts,
      total_farmers: totalFarmers,
      total_customers: totalCustomers,
      expiring_soon: expiringItems,
      timestamp: new Date().toISOString()
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getChartData = async (req, res) => {
  try {
    const { days = 14 } = req.query;
    const start = new Date(); start.setDate(start.getDate() - parseInt(days));
    const startStr = start.toISOString().split('T')[0];

    const [milkTrend, revenueTrend, productionByType, topCustomers] = await Promise.all([
      MilkCollection.findAll({
        where: { factory_id: req.factoryId, collection_date: { [Op.gte]: startStr } },
        attributes: ['collection_date', [sequelize.fn('SUM', sequelize.col('liters')), 'liters'], [sequelize.fn('AVG', sequelize.col('fat_percentage')), 'avg_fat']],
        group: ['collection_date'], order: [['collection_date', 'ASC']]
      }),
      SalesOrder.findAll({
        where: { factory_id: req.factoryId, order_date: { [Op.gte]: startStr }, status: { [Op.in]: ['confirmed', 'delivered'] } },
        attributes: ['order_date', [sequelize.fn('SUM', sequelize.col('total_amount')), 'revenue'], [sequelize.fn('COUNT', sequelize.col('id')), 'orders']],
        group: ['order_date'], order: [['order_date', 'ASC']]
      }),
      ProductionBatch.findAll({
        where: { factory_id: req.factoryId, status: 'completed', production_date: { [Op.gte]: startStr } },
        attributes: ['product_type', [sequelize.fn('SUM', sequelize.col('quantity_produced')), 'total']],
        group: ['product_type']
      }),
      Customer.findAll({
        where: { factory_id: req.factoryId },
        attributes: ['name', 'type', 'total_purchases'],
        order: [['total_purchases', 'DESC']],
        limit: 5
      })
    ]);

    res.json({ milk_trend: milkTrend, revenue_trend: revenueTrend, production_by_type: productionByType, top_customers: topCustomers });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
