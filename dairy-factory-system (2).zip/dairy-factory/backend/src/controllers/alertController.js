const { Alert } = require('../models');

exports.getAll = async (req, res) => {
  try {
    const alerts = await Alert.findAll({
      where: { factory_id: req.factoryId, is_resolved: false },
      order: [['created_at', 'DESC']], limit: 100
    });
    res.json(alerts);
  } catch (err) { res.status(500).json({ error: err.message }); }
};

exports.markRead = async (req, res) => {
  try {
    await Alert.update({ is_read: true, read_by: req.user.id },
      { where: { factory_id: req.factoryId, is_read: false } });
    res.json({ message: 'All alerts marked as read' });
  } catch (err) { res.status(500).json({ error: err.message }); }
};

exports.resolve = async (req, res) => {
  try {
    const alert = await Alert.findOne({ where: { id: req.params.id, factory_id: req.factoryId } });
    if (!alert) return res.status(404).json({ error: 'Alert not found' });
    await alert.update({ is_resolved: true, resolved_by: req.user.id, resolved_at: new Date() });
    res.json(alert);
  } catch (err) { res.status(500).json({ error: err.message }); }
};
