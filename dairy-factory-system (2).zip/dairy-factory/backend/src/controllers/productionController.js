const QRCode = require('qrcode');
const { ProductionBatch, ProductRecipe, Inventory, MilkCollection, sequelize } = require('../models');
const { Op } = require('sequelize');
const { createAlert } = require('../services/alertService');
const { addDays, format } = require('date-fns');

const generateBatchId = () => {
  const date = format(new Date(), 'yyMMdd');
  const rand = Math.floor(Math.random() * 9999).toString().padStart(4, '0');
  return `BAT${date}${rand}`;
};

exports.createBatch = async (req, res) => {
  try {
    const { recipe_id, milk_used_liters, quantity_planned, fat_percentage, quality_score, notes } = req.body;
    
    const recipe = await ProductRecipe.findOne({ where: { id: recipe_id, factory_id: req.factoryId } });
    if (!recipe) return res.status(404).json({ error: 'Recipe not found' });

    // Check available milk
    const today = new Date().toISOString().split('T')[0];
    const availableMilk = await MilkCollection.sum('liters', {
      where: { factory_id: req.factoryId, collection_date: today }
    });

    const production_date = new Date();
    const expiration_date = addDays(production_date, recipe.shelf_life_days);

    const batch = await ProductionBatch.create({
      factory_id: req.factoryId,
      batch_id: generateBatchId(),
      recipe_id,
      product_type: recipe.product_type,
      product_name: recipe.product_name,
      status: 'in_progress',
      production_date: format(production_date, 'yyyy-MM-dd'),
      expiration_date: format(expiration_date, 'yyyy-MM-dd'),
      milk_used_liters,
      quantity_planned,
      fat_percentage,
      quality_score,
      notes,
      started_by: req.user.id,
      started_at: new Date()
    });

    // Generate QR Code
    const qrData = {
      batch_id: batch.batch_id,
      product: recipe.product_name,
      type: recipe.product_type,
      production_date: batch.production_date,
      expiration_date: batch.expiration_date,
      factory: 'SutMahsulot Zavodi',
      milk_used: milk_used_liters,
      qty: quantity_planned
    };

    const qrCode = await QRCode.toDataURL(JSON.stringify(qrData), {
      errorCorrectionLevel: 'H', type: 'image/png', width: 300,
      color: { dark: '#1a1a2e', light: '#ffffff' }
    });

    await batch.update({ qr_code_data: qrCode, qr_code_url: `/api/production/qr/${batch.batch_id}` });

    if (global.io) {
      global.io.to(`factory:${req.factoryId}`).emit('batch_started', {
        batch_id: batch.batch_id, product: recipe.product_name, status: 'in_progress'
      });
    }

    res.status(201).json({ ...batch.toJSON(), qr_code_data: qrCode });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.completeBatch = async (req, res) => {
  try {
    const { id } = req.params;
    const { quantity_produced, quality_score, notes } = req.body;

    const batch = await ProductionBatch.findOne({ where: { id, factory_id: req.factoryId } });
    if (!batch) return res.status(404).json({ error: 'Batch not found' });

    const recipe = await ProductRecipe.findByPk(batch.recipe_id);
    const yield_actual = (quantity_produced / batch.quantity_planned) * 100;

    await batch.update({
      status: 'completed', quantity_produced, quality_score,
      yield_actual, completed_by: req.user.id, completed_at: new Date(), notes
    });

    // Update inventory
    const [inv] = await Inventory.findOrCreate({
      where: { factory_id: req.factoryId, product_type: batch.product_type, batch_id: batch.id },
      defaults: {
        factory_id: req.factoryId, product_type: batch.product_type,
        product_name: batch.product_name, batch_id: batch.id,
        quantity: quantity_produced, unit: 'kg',
        expiration_date: batch.expiration_date,
        price_per_unit: recipe.price_per_unit, min_stock_alert: 50
      }
    });
    if (!inv._options?.isNewRecord) {
      await inv.update({ quantity: parseFloat(inv.quantity) + parseFloat(quantity_produced) });
    }

    // Check expiry alert
    const daysToExpiry = Math.floor((new Date(batch.expiration_date) - new Date()) / (1000 * 60 * 60 * 24));
    if (daysToExpiry <= 3) {
      await createAlert(req.factoryId, 'expiring_soon', 'critical', 'Mahsulot muddati yaqin',
        `${batch.product_name} (${batch.batch_id}) ${daysToExpiry} kunda muddati tugaydi!`, batch.id, 'batch');
    }

    if (global.io) {
      global.io.to(`factory:${req.factoryId}`).emit('batch_completed', {
        batch_id: batch.batch_id, product: batch.product_name, qty: quantity_produced
      });
      global.io.to(`factory:${req.factoryId}`).emit('inventory_updated', { product_type: batch.product_type });
    }

    res.json({ ...batch.toJSON(), yield_actual });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getBatches = async (req, res) => {
  try {
    const { status, product_type, page = 1, limit = 20, date } = req.query;
    const where = { factory_id: req.factoryId };
    if (status) where.status = status;
    if (product_type) where.product_type = product_type;
    if (date) where.production_date = date;

    const { count, rows } = await ProductionBatch.findAndCountAll({
      where, include: [{ model: ProductRecipe, attributes: ['product_name', 'yield_percentage', 'price_per_unit'] }],
      order: [['created_at', 'DESC']],
      limit: parseInt(limit), offset: (parseInt(page) - 1) * parseInt(limit)
    });

    res.json({ total: count, page: parseInt(page), data: rows });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getQR = async (req, res) => {
  try {
    const batch = await ProductionBatch.findOne({ where: { batch_id: req.params.batch_id } });
    if (!batch || !batch.qr_code_data) return res.status(404).json({ error: 'QR not found' });
    const base64Data = batch.qr_code_data.replace(/^data:image\/png;base64,/, '');
    res.set('Content-Type', 'image/png');
    res.send(Buffer.from(base64Data, 'base64'));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getRecipes = async (req, res) => {
  try {
    const recipes = await ProductRecipe.findAll({
      where: { factory_id: req.factoryId, is_active: true }
    });
    res.json(recipes);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getStats = async (req, res) => {
  try {
    const { days = 30 } = req.query;
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - parseInt(days));
    
    const stats = await ProductionBatch.findAll({
      where: { factory_id: req.factoryId, status: 'completed',
        production_date: { [Op.gte]: startDate.toISOString().split('T')[0] } },
      attributes: [
        'product_type', 'production_date',
        [sequelize.fn('SUM', sequelize.col('quantity_produced')), 'total_produced'],
        [sequelize.fn('SUM', sequelize.col('milk_used_liters')), 'total_milk'],
        [sequelize.fn('AVG', sequelize.col('yield_actual')), 'avg_yield'],
        [sequelize.fn('COUNT', sequelize.col('id')), 'batches']
      ],
      group: ['product_type', 'production_date'],
      order: [['production_date', 'ASC']]
    });
    res.json(stats);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
