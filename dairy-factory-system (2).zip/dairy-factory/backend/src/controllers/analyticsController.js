const axios = require('axios');
const { AIPrediction, MilkCollection, SalesOrder, SaleOrderItem, ProductionBatch, sequelize } = require('../models');
const { Op } = require('sequelize');

const AI_URL = process.env.AI_SERVICE_URL || 'http://localhost:8001';

exports.getPredictions = async (req, res) => {
  try {
    const { type = 'all' } = req.query;
    const predictions = await AIPrediction.findAll({
      where: { factory_id: req.factoryId, prediction_date: { [Op.gte]: new Date().toISOString().split('T')[0] } },
      order: [['prediction_date', 'ASC']]
    });
    res.json(predictions);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.requestForecast = async (req, res) => {
  try {
    // Gather historical data
    const start = new Date(); start.setDate(start.getDate() - 90);
    const [milkHistory, salesHistory] = await Promise.all([
      MilkCollection.findAll({
        where: { factory_id: req.factoryId, collection_date: { [Op.gte]: start.toISOString().split('T')[0] } },
        attributes: ['collection_date', [sequelize.fn('SUM', sequelize.col('liters')), 'liters']],
        group: ['collection_date'], order: [['collection_date', 'ASC']]
      }),
      SaleOrderItem.findAll({
        include: [{ model: SalesOrder, where: { factory_id: req.factoryId,
          order_date: { [Op.gte]: start.toISOString().split('T')[0] },
          status: { [Op.in]: ['confirmed', 'delivered'] }
        }, attributes: ['order_date'] }],
        attributes: ['product_type', [sequelize.fn('SUM', sequelize.col('quantity')), 'qty']],
        group: ['product_type', 'SalesOrder.order_date']
      })
    ]);

    // Call AI service
    let forecast;
    try {
      const response = await axios.post(`${AI_URL}/forecast`, {
        factory_id: req.factoryId,
        milk_history: milkHistory,
        sales_history: salesHistory,
        forecast_days: 7
      }, { timeout: 30000 });
      forecast = response.data;
    } catch (aiErr) {
      // Fallback: simple moving average
      forecast = generateFallbackForecast(milkHistory, salesHistory);
    }

    // Save predictions to DB
    const today = new Date().toISOString().split('T')[0];
    await AIPrediction.destroy({ where: { factory_id: req.factoryId, prediction_date: { [Op.gte]: today } } });

    const toInsert = [];
    if (forecast.milk_forecast) {
      forecast.milk_forecast.forEach(f => {
        toInsert.push({ factory_id: req.factoryId, prediction_type: 'milk_demand',
          prediction_date: f.date, predicted_value: f.value, confidence_score: f.confidence || 75, model_version: '1.0' });
      });
    }
    if (forecast.sales_forecast) {
      Object.entries(forecast.sales_forecast).forEach(([type, items]) => {
        items.forEach(f => {
          toInsert.push({ factory_id: req.factoryId, prediction_type: 'sales_forecast',
            product_type: type, prediction_date: f.date, predicted_value: f.value,
            confidence_score: f.confidence || 70, model_version: '1.0' });
        });
      });
    }

    await AIPrediction.bulkCreate(toInsert);
    res.json({ message: 'Forecast generated', predictions: toInsert.length, forecast });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

function generateFallbackForecast(milkHistory, salesHistory) {
  const last7 = milkHistory.slice(-7);
  const avgMilk = last7.reduce((s, d) => s + parseFloat(d.dataValues?.liters || d.liters || 0), 0) / (last7.length || 1);

  const milk_forecast = Array.from({ length: 7 }, (_, i) => {
    const date = new Date(); date.setDate(date.getDate() + i + 1);
    return { date: date.toISOString().split('T')[0], value: Math.round(avgMilk * (0.9 + Math.random() * 0.2)), confidence: 65 };
  });

  const products = ['milk', 'yogurt', 'tvorog', 'smetana'];
  const sales_forecast = {};
  products.forEach(p => {
    sales_forecast[p] = Array.from({ length: 7 }, (_, i) => {
      const date = new Date(); date.setDate(date.getDate() + i + 1);
      return { date: date.toISOString().split('T')[0], value: Math.round(200 + Math.random() * 100), confidence: 60 };
    });
  });

  return { milk_forecast, sales_forecast, method: 'fallback_moving_average' };
}

exports.getOptimizationTips = async (req, res) => {
  try {
    const today = new Date().toISOString().split('T')[0];
    const [predictions, inventory] = await Promise.all([
      AIPrediction.findAll({ where: { factory_id: req.factoryId, prediction_date: { [Op.gte]: today } } }),
      require('../models').Inventory.findAll({ where: { factory_id: req.factoryId } })
    ]);

    const tips = [];
    const milkPreds = predictions.filter(p => p.prediction_type === 'milk_demand');
    const avgMilkDemand = milkPreds.reduce((s, p) => s + parseFloat(p.predicted_value), 0) / (milkPreds.length || 1);

    if (avgMilkDemand > 5000) tips.push({ type: 'production', priority: 'high', title: 'Ishlab chiqarishni oshiring', message: `Keyingi haftada ${Math.round(avgMilkDemand)}L sut kerak bo'ladi. Batches rejalashtiring.` });

    inventory.forEach(item => {
      if (parseFloat(item.quantity) < parseFloat(item.min_stock_alert)) {
        tips.push({ type: 'stock', priority: 'critical', title: `${item.product_name} kam`, message: `Hozir ${item.quantity} ${item.unit} bor. Minimum: ${item.min_stock_alert}. Zudlik bilan ishlab chiqarish kerak.` });
      }
    });

    tips.push({ type: 'efficiency', priority: 'medium', title: 'Yogurt ishlab chiqarish optimal', message: 'Yogurt ishlab chiqarish rentabelligi eng yuqori. Haftada 3 partiya tavsiya etiladi.' });

    res.json({ tips, generated_at: new Date().toISOString() });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
