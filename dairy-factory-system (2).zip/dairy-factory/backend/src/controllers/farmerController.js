const { Farmer, MilkCollection, sequelize } = require('../models');
const { Op } = require('sequelize');

exports.getAll = async (req, res) => {
  try {
    const farmers = await Farmer.findAll({ where: { factory_id: req.factoryId, is_active: true }, order: [['name','ASC']] });
    res.json(farmers);
  } catch (err) { res.status(500).json({ error: err.message }); }
};

exports.create = async (req, res) => {
  try {
    const farmer = await Farmer.create({ ...req.body, factory_id: req.factoryId });
    res.status(201).json(farmer);
  } catch (err) { res.status(500).json({ error: err.message }); }
};

exports.update = async (req, res) => {
  try {
    const farmer = await Farmer.findOne({ where: { id: req.params.id, factory_id: req.factoryId } });
    if (!farmer) return res.status(404).json({ error: 'Farmer not found' });
    await farmer.update(req.body);
    res.json(farmer);
  } catch (err) { res.status(500).json({ error: err.message }); }
};

exports.getStats = async (req, res) => {
  try {
    const { id } = req.params;
    const { days = 30 } = req.query;
    const startDate = new Date(); startDate.setDate(startDate.getDate() - parseInt(days));
    const collections = await MilkCollection.findAll({
      where: { farmer_id: id, factory_id: req.factoryId, collection_date: { [Op.gte]: startDate.toISOString().split('T')[0] } },
      order: [['collection_date', 'DESC']]
    });
    const summary = { total_liters: 0, total_payment: 0, avg_fat: 0, deliveries: collections.length };
    collections.forEach(c => {
      summary.total_liters += parseFloat(c.liters);
      summary.total_payment += parseFloat(c.total_payment);
      summary.avg_fat += parseFloat(c.fat_percentage);
    });
    if (collections.length) summary.avg_fat /= collections.length;
    res.json({ summary, collections });
  } catch (err) { res.status(500).json({ error: err.message }); }
};
