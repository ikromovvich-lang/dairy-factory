const jwt = require('jsonwebtoken');
const { User } = require('../models');

const authenticate = async (req, res, next) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) return res.status(401).json({ error: 'No token provided' });
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'SuperSecretJWT2024!');
    const user = await User.findByPk(decoded.id, { attributes: { exclude: ['password_hash', 'refresh_token_hash'] } });
    if (!user || !user.is_active) return res.status(401).json({ error: 'Invalid or expired token' });
    req.user = user;
    req.factoryId = user.factory_id;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Token invalid or expired' });
  }
};

const authorize = (...roles) => (req, res, next) => {
  if (!roles.includes(req.user.role)) {
    return res.status(403).json({ error: 'Insufficient permissions' });
  }
  next();
};

module.exports = { authenticate, authorize };
