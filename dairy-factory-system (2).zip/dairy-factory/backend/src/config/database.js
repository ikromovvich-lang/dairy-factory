const { Sequelize } = require('sequelize');
const sequelize = new Sequelize(process.env.DATABASE_URL || 'postgresql://dairy_admin:DairySecure2024!@localhost:5432/dairy_factory', {
  dialect: 'postgres',
  logging: false,
  pool: { max: 20, min: 2, acquire: 30000, idle: 10000 },
  dialectOptions: { ssl: process.env.NODE_ENV === 'production' ? { require: true, rejectUnauthorized: false } : false }
});
module.exports = { sequelize };
