const { createClient } = require('redis');
let redisClient = null;
async function initRedis() {
  try {
    redisClient = createClient({ url: process.env.REDIS_URL || 'redis://localhost:6379' });
    redisClient.on('error', () => {});
    await redisClient.connect();
    return redisClient;
  } catch { return null; }
}
function getRedis() { return redisClient; }
async function cacheGet(key) {
  if (!redisClient) return null;
  try { const v = await redisClient.get(key); return v ? JSON.parse(v) : null; } catch { return null; }
}
async function cacheSet(key, value, ttl = 300) {
  if (!redisClient) return;
  try { await redisClient.setEx(key, ttl, JSON.stringify(value)); } catch {}
}
async function cacheDel(key) {
  if (!redisClient) return;
  try { await redisClient.del(key); } catch {}
}
module.exports = { initRedis, getRedis, cacheGet, cacheSet, cacheDel };
